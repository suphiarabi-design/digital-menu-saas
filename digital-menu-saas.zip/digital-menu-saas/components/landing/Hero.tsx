"use client";

import { motion } from "framer-motion";
import { ArrowLeft, Eye, Sparkles } from "lucide-react";
import Link from "next/link";
import PhoneMockup from "./PhoneMockup";

const STATS = [
  { value: "3", label: "ثيمات احترافية" },
  { value: "0%", label: "عمولة على الطلبات" },
  { value: "5 دقائق", label: "للإطلاق" },
];

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.1 } },
};
const item = {
  hidden: { opacity: 0, y: 22 },
  show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" as const } },
};

export default function Hero() {
  return (
    <section className="aurora relative overflow-hidden pb-20 pt-32 md:pb-28 md:pt-40">
      <div className="mx-auto grid max-w-6xl items-center gap-16 px-5 lg:grid-cols-[1.05fr_0.95fr]">
        <motion.div variants={container} initial="hidden" animate="show">
          <motion.span
            variants={item}
            className="glass inline-flex items-center gap-2 rounded-full px-4 py-2 text-xs font-extrabold text-violet-700"
          >
            <Sparkles size={14} />
            منصة واحدة · ثلاثة أنشطة · تجربة مصممة لكل نشاط
          </motion.span>

          <motion.h1
            variants={item}
            className="mt-6 text-balance text-4xl font-extrabold leading-[1.25] tracking-tight sm:text-5xl lg:text-6xl"
          >
            متجرك أو منيوك الرقمي
            <br />
            <span className="animate-gradient-x bg-gradient-to-l from-violet-600 via-fuchsia-500 to-orange-500 bg-[length:200%_200%] bg-clip-text text-transparent">
              جاهز في 5 دقائق
            </span>
          </motion.h1>

          <motion.p
            variants={item}
            className="mt-6 max-w-xl text-lg leading-8 text-slate-600"
          >
            سواء كنت تدير كافيه أو متجر تجميل أو متجراً عاماً، اختر نشاطك فيتحول
            متجرك تلقائياً إلى التصميم الأنسب له، وتستقبل الطلبات مرتّبة مباشرة على
            واتساب بدون عمولات.
          </motion.p>

          <motion.div variants={item} className="mt-9 flex flex-wrap items-center gap-3">
            <Link href="/dashboard" className="btn btn-dark !px-7 !py-4 text-base">
              ابدأ متجرك مجاناً
              <ArrowLeft size={18} />
            </Link>
            <a href="#niches" className="btn btn-ghost !px-7 !py-4 text-base">
              <Eye size={18} />
              شاهد المتاجر التجريبية
            </a>
          </motion.div>

          <motion.dl variants={item} className="mt-12 grid max-w-md grid-cols-3 gap-4">
            {STATS.map((s) => (
              <div key={s.label}>
                <dt className="text-2xl font-extrabold text-slate-900">{s.value}</dt>
                <dd className="mt-1 text-xs font-bold leading-5 text-slate-500">{s.label}</dd>
              </div>
            ))}
          </motion.dl>
        </motion.div>

        <motion.div
          id="preview"
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <PhoneMockup />
        </motion.div>
      </div>
    </section>
  );
}
