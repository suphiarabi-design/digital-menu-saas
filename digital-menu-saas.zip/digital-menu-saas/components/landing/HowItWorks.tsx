"use client";

import { motion } from "framer-motion";
import { QrCode, Store, UtensilsCrossed } from "lucide-react";

const STEPS = [
  {
    icon: Store,
    title: "اختر نشاطك",
    text: "حدّد هل متجرك للطعام والقهوة أو التجميل أو التجزئة، وسنجهّز لك الثيم المناسب مع منتجات نموذجية.",
  },
  {
    icon: UtensilsCrossed,
    title: "أضف منتجاتك وهويتك",
    text: "اكتب اسم علامتك ورقم واتساب، اختر لونك المفضل، وأضف المنتجات والفئات والأسعار.",
  },
  {
    icon: QrCode,
    title: "شارك واستقبل الطلبات",
    text: "حمّل رمز QR أو شارك رابط متجرك، وتصلك الطلبات منظمة على واتساب فور اكتمالها.",
  },
];

export default function HowItWorks() {
  return (
    <section id="how" className="mx-auto max-w-6xl scroll-mt-24 px-5 py-24">
      <div className="mx-auto max-w-2xl text-center">
        <p className="text-sm font-extrabold text-violet-600">كيف يعمل</p>
        <h2 className="mt-3 text-balance text-3xl font-extrabold leading-snug sm:text-4xl">
          من الفكرة إلى أول طلب في ثلاث خطوات
        </h2>
      </div>

      <div className="relative mt-16 grid gap-10 md:grid-cols-3">
        <div
          aria-hidden
          className="absolute inset-x-[16%] top-8 hidden h-px bg-gradient-to-l from-transparent via-slate-300 to-transparent md:block"
        />
        {STEPS.map((s, i) => (
          <motion.div
            key={s.title}
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.5, delay: i * 0.12 }}
            className="relative text-center"
          >
            <div className="relative mx-auto grid h-16 w-16 place-items-center rounded-3xl bg-slate-900 text-white shadow-lift">
              <s.icon size={26} />
              <span className="absolute -end-2 -top-2 grid h-7 w-7 place-items-center rounded-full bg-gradient-to-br from-violet-500 to-fuchsia-500 text-xs font-extrabold">
                {i + 1}
              </span>
            </div>
            <h3 className="mt-6 text-lg font-extrabold">{s.title}</h3>
            <p className="mx-auto mt-2 max-w-xs text-sm leading-7 text-slate-600">{s.text}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
