"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Menu, X } from "lucide-react";
import Link from "next/link";
import { useEffect, useState } from "react";
import Logo from "@/components/ui/Logo";
import { cn } from "@/lib/utils";

const LINKS = [
  { href: "#features", label: "المزايا" },
  { href: "#niches", label: "الأنشطة" },
  { href: "#how", label: "كيف يعمل" },
  { href: "#pricing", label: "الأسعار" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className="fixed inset-x-0 top-0 z-50 px-3 pt-3 sm:px-5">
      <div
        className={cn(
          "mx-auto max-w-6xl rounded-full border px-4 py-2.5 transition-all duration-300 sm:px-6",
          scrolled
            ? "glass-strong border-white/70"
            : "border-transparent bg-transparent",
        )}
      >
        <div className="flex items-center justify-between">
          <Logo />

          <nav className="hidden items-center gap-1 md:flex" aria-label="التنقل الرئيسي">
            {LINKS.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className="rounded-full px-4 py-2 text-sm font-bold text-slate-600 transition hover:bg-black/5 hover:text-slate-900"
              >
                {l.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <Link href="/dashboard" className="btn btn-dark hidden !py-2 sm:inline-flex">
              ابدأ مجاناً
            </Link>
            <button
              type="button"
              className="grid h-10 w-10 place-items-center rounded-full text-slate-700 transition hover:bg-black/5 md:hidden"
              onClick={() => setOpen((v) => !v)}
              aria-label={open ? "إغلاق القائمة" : "فتح القائمة"}
              aria-expanded={open}
            >
              {open ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>

        <AnimatePresence>
          {open && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden md:hidden"
            >
              <div className="flex flex-col gap-1 pb-3 pt-4">
                {LINKS.map((l) => (
                  <a
                    key={l.href}
                    href={l.href}
                    onClick={() => setOpen(false)}
                    className="rounded-2xl px-4 py-3 text-sm font-bold text-slate-700 hover:bg-black/5"
                  >
                    {l.label}
                  </a>
                ))}
                <Link href="/dashboard" className="btn btn-dark mt-2">
                  ابدأ مجاناً
                </Link>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </header>
  );
}
