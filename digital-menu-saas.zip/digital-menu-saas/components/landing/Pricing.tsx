"use client";

import { motion } from "framer-motion";
import { Check } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { cn } from "@/lib/utils";

interface Tier {
  id: string;
  name: string;
  description: string;
  monthly: number;
  features: string[];
  cta: string;
  popular?: boolean;
}

const TIERS: Tier[] = [
  {
    id: "starter",
    name: "البداية",
    description: "للتجربة والمتاجر الصغيرة",
    monthly: 0,
    features: [
      "متجر واحد",
      "حتى 25 منتجاً",
      "الثيمات الثلاثة",
      "رمز QR قابل للتحميل",
      "طلبات واتساب غير محدودة",
    ],
    cta: "ابدأ مجاناً",
  },
  {
    id: "pro",
    name: "المحترف",
    description: "للأنشطة النامية",
    monthly: 79,
    features: [
      "حتى 500 منتج",
      "هوية وألوان مخصصة",
      "إزالة شعار المنصة",
      "نطاق مخصص لمتجرك",
      "دعم ذو أولوية",
    ],
    cta: "جرّب المحترف",
    popular: true,
  },
  {
    id: "business",
    name: "الأعمال",
    description: "للسلاسل والفروع المتعددة",
    monthly: 199,
    features: [
      "منتجات غير محدودة",
      "حتى 5 فروع",
      "فريق عمل بصلاحيات",
      "تقارير وتحليلات الطلبات",
      "مدير حساب مخصص",
    ],
    cta: "تواصل معنا",
  },
];

export default function Pricing() {
  const [yearly, setYearly] = useState(true);

  return (
    <section id="pricing" className="scroll-mt-24 bg-white/60 py-24">
      <div className="mx-auto max-w-6xl px-5">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-extrabold text-violet-600">الأسعار</p>
          <h2 className="mt-3 text-balance text-3xl font-extrabold leading-snug sm:text-4xl">
            خطط بسيطة تنمو مع تجارتك
          </h2>
          <p className="mt-4 leading-8 text-slate-600">
            ابدأ مجاناً وارتقِ عندما تحتاج. بدون عمولة على أي طلب في جميع الخطط.
          </p>

          <div
            role="group"
            aria-label="دورة الفوترة"
            className="mx-auto mt-8 inline-flex rounded-full bg-slate-100 p-1.5"
          >
            {[
              { id: false, label: "شهري" },
              { id: true, label: "سنوي · وفّر 20%" },
            ].map((opt) => (
              <button
                key={String(opt.id)}
                type="button"
                onClick={() => setYearly(opt.id)}
                aria-pressed={yearly === opt.id}
                className={cn(
                  "relative rounded-full px-5 py-2.5 text-sm font-extrabold transition",
                  yearly === opt.id ? "text-slate-900" : "text-slate-500",
                )}
              >
                {yearly === opt.id && (
                  <motion.span
                    layoutId="billing-pill"
                    className="absolute inset-0 rounded-full bg-white shadow-soft"
                    transition={{ type: "spring", stiffness: 420, damping: 34 }}
                  />
                )}
                <span className="relative">{opt.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="mt-14 grid items-stretch gap-6 lg:grid-cols-3">
          {TIERS.map((tier, i) => {
            const price = yearly ? Math.round(tier.monthly * 0.8) : tier.monthly;
            return (
              <motion.article
                key={tier.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                className={cn(
                  "relative flex flex-col rounded-[32px] p-8",
                  tier.popular
                    ? "bg-slate-900 text-white shadow-lift lg:-my-4 lg:py-12"
                    : "border border-slate-100 bg-white shadow-soft",
                )}
              >
                {tier.popular && (
                  <span className="absolute -top-3.5 start-1/2 -translate-x-1/2 rounded-full bg-gradient-to-l from-violet-500 to-fuchsia-500 px-4 py-1.5 text-xs font-extrabold text-white shadow-soft">
                    الأكثر اختياراً
                  </span>
                )}

                <h3 className="text-xl font-extrabold">{tier.name}</h3>
                <p className={cn("mt-1 text-sm", tier.popular ? "text-slate-300" : "text-slate-500")}>
                  {tier.description}
                </p>

                <p className="mt-7 flex items-baseline gap-2">
                  <motion.span
                    key={price}
                    initial={{ opacity: 0, y: -8 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-5xl font-extrabold tracking-tight"
                  >
                    {price}
                  </motion.span>
                  <span className={cn("text-sm font-bold", tier.popular ? "text-slate-300" : "text-slate-500")}>
                    ر.س / شهرياً
                  </span>
                </p>
                <p className={cn("mt-1 h-5 text-xs", tier.popular ? "text-slate-400" : "text-slate-400")}>
                  {tier.monthly > 0 && yearly ? "تُدفع سنوياً" : ""}
                </p>

                <ul className="mt-6 flex-1 space-y-3.5">
                  {tier.features.map((f) => (
                    <li key={f} className="flex items-center gap-3 text-sm font-bold">
                      <span
                        className={cn(
                          "grid h-5 w-5 shrink-0 place-items-center rounded-full",
                          tier.popular ? "bg-white/15 text-white" : "bg-violet-100 text-violet-600",
                        )}
                      >
                        <Check size={12} strokeWidth={3} />
                      </span>
                      {f}
                    </li>
                  ))}
                </ul>

                <Link
                  href="/dashboard"
                  className={cn(
                    "btn mt-9 w-full !py-3.5",
                    tier.popular ? "bg-white text-slate-900 hover:bg-slate-100" : "btn-dark",
                  )}
                >
                  {tier.cta}
                </Link>
              </motion.article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
