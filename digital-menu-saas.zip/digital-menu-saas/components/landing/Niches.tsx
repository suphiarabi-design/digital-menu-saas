"use client";

import { motion } from "framer-motion";
import { ArrowLeft, Check } from "lucide-react";
import Link from "next/link";
import { NICHE_LIST } from "@/lib/themes";
import { brandVars } from "@/lib/utils";

export default function Niches() {
  return (
    <section id="niches" className="scroll-mt-24 bg-white/60 py-24">
      <div className="mx-auto max-w-6xl px-5">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-extrabold text-violet-600">متعدد الأنشطة</p>
          <h2 className="mt-3 text-balance text-3xl font-extrabold leading-snug sm:text-4xl">
            ثلاثة ثيمات، كل واحد مصمم لنشاطك
          </h2>
          <p className="mt-4 leading-8 text-slate-600">
            لا قالب واحد للجميع. كل ثيم يغيّر التخطيط وطريقة الطلب وحقول الدفع لتناسب
            عملاءك.
          </p>
        </div>

        <div className="mt-14 grid gap-6 lg:grid-cols-3">
          {NICHE_LIST.map((n, i) => (
            <motion.article
              key={n.id}
              style={brandVars(n.defaultColor)}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.55, delay: i * 0.1 }}
              className="group overflow-hidden rounded-[32px] border border-slate-100 bg-white shadow-soft transition-shadow hover:shadow-lift"
            >
              <div
                className="relative flex h-44 items-end justify-between overflow-hidden p-6"
                style={{
                  background: "linear-gradient(135deg, var(--brand), var(--brand-strong))",
                  color: "var(--brand-contrast)",
                }}
              >
                <span className="absolute -end-8 -top-8 h-40 w-40 rounded-full bg-white/20 blur-2xl" />
                <span className="absolute -bottom-10 start-6 h-32 w-32 rounded-full bg-black/10 blur-2xl" />
                <span className="relative text-6xl transition duration-500 group-hover:scale-110 group-hover:-rotate-6">
                  {n.emoji}
                </span>
                <span className="relative rounded-full bg-white/20 px-3 py-1.5 text-xs font-extrabold backdrop-blur">
                  {n.label}
                </span>
              </div>

              <div className="p-7">
                <h3 className="text-xl font-extrabold">{n.title}</h3>
                <p className="mt-2 text-sm leading-7 text-slate-600">{n.description}</p>

                <ul className="mt-5 space-y-2.5">
                  {n.highlights.map((h) => (
                    <li key={h} className="flex items-center gap-2.5 text-sm font-bold text-slate-700">
                      <span
                        className="grid h-5 w-5 place-items-center rounded-full"
                        style={{ background: "var(--brand-soft)", color: "var(--brand)" }}
                      >
                        <Check size={12} strokeWidth={3} />
                      </span>
                      {h}
                    </li>
                  ))}
                </ul>

                <Link
                  href={`/${n.demoSlug}`}
                  className="btn btn-brand mt-7 w-full"
                >
                  شاهد المتجر التجريبي
                  <ArrowLeft size={16} />
                </Link>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}
