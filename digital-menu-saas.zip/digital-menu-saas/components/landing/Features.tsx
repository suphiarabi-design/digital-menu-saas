"use client";

import { motion } from "framer-motion";
import {
  Languages,
  MessageCircle,
  Palette,
  QrCode,
  Smartphone,
  Zap,
} from "lucide-react";

const FEATURES = [
  {
    icon: Palette,
    title: "محرك ثيمات متعدد",
    text: "اختر نشاطك (طعام، تجميل، تجزئة) فيتحول المتجر تلقائياً إلى تصميم وتجربة تناسبه، وبدّل الثيم لاحقاً بضغطة واحدة.",
    tone: "from-violet-500 to-fuchsia-500",
  },
  {
    icon: MessageCircle,
    title: "طلبات منظمة عبر واتساب",
    text: "رسالة جاهزة بتفاصيل الطلب والإجمالي ورقم الطاولة أو العنوان تصلك مباشرة، بدون عمولات ولا وسطاء.",
    tone: "from-emerald-500 to-teal-500",
  },
  {
    icon: QrCode,
    title: "رمز QR فوري",
    text: "حمّل رمز QR بجودة عالية بلون هويتك، وضعه على الطاولات أو الواجهة أو المطبوعات.",
    tone: "from-slate-700 to-slate-900",
  },
  {
    icon: Smartphone,
    title: "سلة عائمة للجوال",
    text: "سلة سريعة تثبت أسفل الشاشة وتتحول إلى لوحة كاملة عند إتمام الطلب، مصممة لتناسب إبهام العميل.",
    tone: "from-sky-500 to-blue-600",
  },
  {
    icon: Zap,
    title: "إدارة منتجات سريعة",
    text: "أضف وعدّل ورتّب منتجاتك وفئاتك في ثوانٍ، مع الأسعار والأوصاف والصور وخيارات المقاسات.",
    tone: "from-amber-500 to-orange-500",
  },
  {
    icon: Languages,
    title: "عربي بالكامل من اليمين لليسار",
    text: "واجهات RTL أصيلة بخط تجوال الأنيق، وتجربة مصممة للمتسوق العربي من أول تفصيلة.",
    tone: "from-rose-500 to-pink-600",
  },
];

export default function Features() {
  return (
    <section id="features" className="mx-auto max-w-6xl scroll-mt-24 px-5 py-24">
      <div className="mx-auto max-w-2xl text-center">
        <p className="text-sm font-extrabold text-violet-600">المزايا</p>
        <h2 className="mt-3 text-balance text-3xl font-extrabold leading-snug sm:text-4xl">
          كل ما تحتاجه لتبيع أونلاين، في مكان واحد
        </h2>
        <p className="mt-4 leading-8 text-slate-600">
          أدوات بسيطة وقوية صُمّمت للتجار الذين يريدون الإطلاق اليوم، لا بعد أسابيع.
        </p>
      </div>

      <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {FEATURES.map((f, i) => (
          <motion.article
            key={f.title}
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.5, delay: (i % 3) * 0.08 }}
            whileHover={{ y: -6 }}
            className="group rounded-[28px] border border-white bg-white/70 p-7 shadow-soft backdrop-blur transition-shadow hover:shadow-lift"
          >
            <span
              className={`grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br ${f.tone} text-white shadow-soft transition group-hover:scale-110`}
            >
              <f.icon size={22} />
            </span>
            <h3 className="mt-5 text-lg font-extrabold">{f.title}</h3>
            <p className="mt-2 text-sm leading-7 text-slate-600">{f.text}</p>
          </motion.article>
        ))}
      </div>
    </section>
  );
}
