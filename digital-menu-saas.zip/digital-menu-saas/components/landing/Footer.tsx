import Link from "next/link";
import Logo from "@/components/ui/Logo";
import { BRAND } from "@/lib/brand";
import { NICHE_LIST } from "@/lib/themes";

export default function Footer() {
  return (
    <footer className="border-t border-slate-200/70 bg-white">
      <div className="mx-auto grid max-w-6xl gap-10 px-5 py-14 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <Logo />
          <p className="mt-4 max-w-xs text-sm leading-7 text-slate-500">
            {BRAND.tagline}. أنشئ متجرك أو منيوك الرقمي واستقبل طلباتك على واتساب في دقائق.
          </p>
        </div>

        <nav aria-label="المنصة">
          <h4 className="text-sm font-extrabold">المنصة</h4>
          <ul className="mt-4 space-y-3 text-sm text-slate-500">
            <li>
              <a href="#features" className="hover:text-slate-900">المزايا</a>
            </li>
            <li>
              <a href="#pricing" className="hover:text-slate-900">الأسعار</a>
            </li>
            <li>
              <Link href="/dashboard" className="hover:text-slate-900">لوحة التحكم</Link>
            </li>
          </ul>
        </nav>

        <nav aria-label="المتاجر التجريبية">
          <h4 className="text-sm font-extrabold">متاجر تجريبية</h4>
          <ul className="mt-4 space-y-3 text-sm text-slate-500">
            {NICHE_LIST.map((n) => (
              <li key={n.id}>
                <Link href={`/${n.demoSlug}`} className="hover:text-slate-900">
                  {n.emoji} {n.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>

      <div className="border-t border-slate-100 py-6 text-center text-xs text-slate-400">
        © {new Date().getFullYear()} {BRAND.name}. جميع الحقوق محفوظة.
      </div>
    </footer>
  );
}
