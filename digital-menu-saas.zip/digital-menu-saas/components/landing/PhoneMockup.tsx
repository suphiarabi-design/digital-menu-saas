"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Check, Plus, QrCode, Search, ShoppingBag } from "lucide-react";
import { useEffect, useState } from "react";
import ProductImage from "@/components/storefront/ProductImage";
import { DEMO_STORES } from "@/lib/seed";
import { NICHES, NICHE_LIST } from "@/lib/themes";
import type { Niche, StoreSettings } from "@/lib/types";
import { brandVars, cn, formatPrice } from "@/lib/utils";

const ORDER: Niche[] = ["food", "cosmetics", "retail"];

const DEMOS: Record<Niche, StoreSettings> = {
  food: DEMO_STORES["cafe-demo"],
  cosmetics: DEMO_STORES["glow-demo"],
  retail: DEMO_STORES["urban-demo"],
};

interface MiniProps {
  store: StoreSettings;
  onAdd: (price: number) => void;
}

/**
 * Live, interactive preview of the three storefront themes inside a phone
 * frame. Auto-rotates, and the "+" buttons really update the cart bar.
 */
export default function PhoneMockup() {
  const [niche, setNiche] = useState<Niche>("food");
  const [paused, setPaused] = useState(false);
  const [count, setCount] = useState(0);
  const [total, setTotal] = useState(0);

  useEffect(() => {
    if (paused) return;
    const timer = setInterval(() => {
      setNiche((n) => ORDER[(ORDER.indexOf(n) + 1) % ORDER.length]);
    }, 5200);
    return () => clearInterval(timer);
  }, [paused]);

  // Each theme starts with a fresh cart.
  useEffect(() => {
    setCount(0);
    setTotal(0);
  }, [niche]);

  const store = DEMOS[niche];
  const addToCart = (price: number) => {
    setCount((c) => c + 1);
    setTotal((t) => t + price);
  };

  return (
    <div
      className="relative mx-auto w-full max-w-[400px]"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      {/* Glow behind the phone follows the active theme colour */}
      <motion.div
        aria-hidden
        className="absolute inset-x-6 top-16 -z-10 h-[420px] rounded-full blur-3xl"
        animate={{ backgroundColor: store.primaryColor, opacity: 0.28 }}
        transition={{ duration: 0.8 }}
      />

      {/* Theme tabs */}
      <div className="glass mx-auto mb-5 flex w-fit gap-1 rounded-full p-1.5">
        {NICHE_LIST.map((n) => {
          const active = n.id === niche;
          return (
            <button
              key={n.id}
              type="button"
              onClick={() => {
                setNiche(n.id);
                setPaused(true);
              }}
              className={cn(
                "relative rounded-full px-4 py-2 text-xs font-extrabold transition",
                active ? "text-white" : "text-slate-600 hover:text-slate-900",
              )}
            >
              {active && (
                <motion.span
                  layoutId="mock-tab"
                  className="absolute inset-0 rounded-full bg-slate-900"
                  transition={{ type: "spring", stiffness: 420, damping: 34 }}
                />
              )}
              <span className="relative">
                {n.emoji} {n.label.split(" ")[0]}
              </span>
            </button>
          );
        })}
      </div>

      {/* Phone */}
      <div className="relative mx-auto h-[600px] w-[292px] rounded-[48px] border-[10px] border-slate-900 bg-slate-900 shadow-lift">
        <div className="absolute left-1/2 top-2 z-20 h-5 w-24 -translate-x-1/2 rounded-full bg-slate-900" />
        <div
          style={brandVars(store.primaryColor)}
          className={cn("relative h-full overflow-hidden rounded-[38px]", NICHES[niche].page)}
        >
          <AnimatePresence mode="wait">
            <motion.div
              key={niche}
              initial={{ opacity: 0, x: 24 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -24 }}
              transition={{ duration: 0.35 }}
              className="h-full"
            >
              {niche === "food" && <MiniFood store={store} onAdd={addToCart} />}
              {niche === "cosmetics" && <MiniCosmetics store={store} onAdd={addToCart} />}
              {niche === "retail" && <MiniRetail store={store} onAdd={addToCart} />}
            </motion.div>
          </AnimatePresence>

          {/* Instant cart bar */}
          <AnimatePresence>
            {count > 0 && (
              <motion.div
                initial={{ y: 70, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                exit={{ y: 70, opacity: 0 }}
                transition={{ type: "spring", damping: 24, stiffness: 320 }}
                className="btn-brand absolute inset-x-3 bottom-4 z-10 flex items-center justify-between rounded-full px-3 py-2.5 shadow-lift"
              >
                <span className="flex items-center gap-2 text-xs font-extrabold">
                  <span className="relative grid h-8 w-8 place-items-center rounded-full bg-white/20">
                    <ShoppingBag size={15} />
                    <motion.span
                      key={count}
                      initial={{ scale: 1.5 }}
                      animate={{ scale: 1 }}
                      className="absolute -end-1 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-white px-1 text-[9px] font-extrabold text-slate-900"
                    >
                      {count}
                    </motion.span>
                  </span>
                  عرض السلة
                </span>
                <span className="pe-2 text-xs font-extrabold">
                  {formatPrice(total, store.currency)}
                </span>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Floating glass badges */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.6 }}
        className="absolute -start-4 top-32 hidden sm:block"
      >
        <div className="glass-strong flex animate-float items-center gap-2.5 rounded-2xl px-3.5 py-2.5">
          <span className="grid h-8 w-8 place-items-center rounded-full bg-emerald-500 text-white">
            <Check size={16} />
          </span>
          <div className="leading-tight">
            <p className="text-xs font-extrabold">طلب جديد</p>
            <p className="text-[11px] text-slate-500">وصل عبر واتساب</p>
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.8 }}
        className="absolute -end-4 bottom-40 hidden sm:block"
      >
        <div className="glass-strong flex animate-float-slow items-center gap-2.5 rounded-2xl px-3.5 py-2.5">
          <span className="grid h-8 w-8 place-items-center rounded-full bg-slate-900 text-white">
            <QrCode size={16} />
          </span>
          <div className="leading-tight">
            <p className="text-xs font-extrabold">رمز QR جاهز</p>
            <p className="text-[11px] text-slate-500">للطباعة والمشاركة</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Mini themes                                                         */
/* ------------------------------------------------------------------ */

function MiniFood({ store, onAdd }: MiniProps) {
  const items = store.products.slice(0, 4);
  return (
    <div className="h-full overflow-hidden">
      <div
        className="px-4 pb-9 pt-10"
        style={{
          background: "linear-gradient(135deg, var(--brand), var(--brand-strong))",
          color: "var(--brand-contrast)",
        }}
      >
        <div className="flex items-center gap-2.5">
          <span className="grid h-10 w-10 place-items-center rounded-2xl bg-white/20 text-lg">☕</span>
          <div>
            <p className="text-sm font-extrabold leading-tight">{store.brandName}</p>
            <p className="text-[10px] opacity-90">🪑 اطلب من طاولتك</p>
          </div>
        </div>
      </div>

      <div className="-mt-4 rounded-t-3xl bg-[#FFF9F2] px-3 pt-3">
        <div className="no-scrollbar flex gap-1.5 overflow-hidden pb-2.5">
          {store.categories.slice(0, 3).map((c, i) => (
            <span
              key={c}
              className={cn(
                "shrink-0 rounded-full px-3 py-1.5 text-[10px] font-bold",
                i === 0 ? "" : "bg-white text-slate-500 ring-1 ring-black/5",
              )}
              style={i === 0 ? { background: "var(--brand)", color: "var(--brand-contrast)" } : undefined}
            >
              {c}
            </span>
          ))}
        </div>

        <div className="space-y-2.5">
          {items.map((p) => (
            <div key={p.id} className="flex items-center gap-2.5 rounded-2xl bg-white p-2 shadow-soft ring-1 ring-black/5">
              <ProductImage product={p} className="h-14 w-14 shrink-0 rounded-xl" emojiClassName="text-2xl" />
              <div className="min-w-0 flex-1">
                <p className="truncate text-xs font-extrabold">{p.name}</p>
                <p className="mt-0.5 text-[11px] font-bold" style={{ color: "var(--brand)" }}>
                  {formatPrice(p.price, store.currency)}
                </p>
              </div>
              <button
                type="button"
                onClick={() => onAdd(p.price)}
                aria-label={`أضف ${p.name}`}
                className="btn-brand grid h-8 w-8 shrink-0 place-items-center rounded-full transition active:scale-90"
              >
                <Plus size={15} />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function MiniCosmetics({ store, onAdd }: MiniProps) {
  const items = store.products.slice(0, 4);
  return (
    <div className="h-full overflow-hidden px-3.5 pt-9">
      <div className="flex items-center justify-between">
        <span className="w-6" />
        <p className="text-sm font-light tracking-[0.2em]">{store.brandName}</p>
        <ShoppingBag size={16} strokeWidth={1.6} />
      </div>
      <div className="mt-5 text-center">
        <p className="text-[9px] font-bold tracking-[0.3em]" style={{ color: "var(--brand)" }}>
          COLLECTION
        </p>
        <p className="mt-1 text-lg font-light leading-snug">{store.tagline.split("•")[0].trim()}</p>
      </div>
      <div className="mt-4 grid grid-cols-2 gap-x-2.5 gap-y-3">
        {items.map((p) => (
          <div key={p.id}>
            <div className="relative">
              <ProductImage product={p} className="aspect-[4/5] w-full rounded-2xl" emojiClassName="text-4xl" />
              <button
                type="button"
                onClick={() => onAdd(p.price)}
                aria-label={`أضف ${p.name}`}
                className="btn-brand absolute bottom-1.5 end-1.5 grid h-7 w-7 place-items-center rounded-full transition active:scale-90"
              >
                <Plus size={13} />
              </button>
            </div>
            <p className="mt-1.5 truncate text-[11px] font-bold">{p.name}</p>
            <p className="text-[10px] font-bold" style={{ color: "var(--brand)" }}>
              {formatPrice(p.price, store.currency)}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}

function MiniRetail({ store, onAdd }: MiniProps) {
  const items = store.products.slice(0, 4);
  return (
    <div className="h-full overflow-hidden">
      <div
        className="px-3 py-1.5 pt-7 text-center text-[9px] font-bold"
        style={{ background: "var(--brand)", color: "var(--brand-contrast)" }}
      >
        اطلب الآن عبر واتساب
      </div>
      <div className="flex items-center gap-2 border-b border-slate-200 bg-white px-3 py-2.5">
        <p className="text-xs font-extrabold">{store.brandName}</p>
        <div className="flex flex-1 items-center gap-1.5 rounded-full bg-slate-100 px-2.5 py-1.5 text-[10px] text-slate-400">
          <Search size={11} /> ابحث…
        </div>
        <ShoppingBag size={15} />
      </div>
      <div className="flex gap-1.5 overflow-hidden px-3 pt-3">
        {["الكل", ...store.categories.slice(0, 2)].map((c, i) => (
          <span
            key={c}
            className={cn(
              "shrink-0 rounded-full border px-2.5 py-1 text-[10px] font-bold",
              i === 0 ? "border-transparent" : "border-slate-200 bg-white text-slate-500",
            )}
            style={i === 0 ? { background: "var(--brand)", color: "var(--brand-contrast)" } : undefined}
          >
            {c}
          </span>
        ))}
      </div>
      <div className="mt-3 grid grid-cols-2 gap-2.5 px-3">
        {items.map((p) => (
          <div key={p.id} className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
            <ProductImage product={p} className="aspect-square w-full" emojiClassName="text-4xl" />
            <div className="p-2">
              <p className="truncate text-[11px] font-extrabold">{p.name}</p>
              <div className="mt-1.5 flex items-center justify-between">
                <p className="text-[10px] font-extrabold">{formatPrice(p.price, store.currency)}</p>
                <button
                  type="button"
                  onClick={() => onAdd(p.price)}
                  className="btn-brand rounded-full px-2.5 py-1 text-[9px] font-extrabold transition active:scale-90"
                >
                  أضف
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
