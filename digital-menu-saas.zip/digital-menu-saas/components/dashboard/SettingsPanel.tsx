"use client";

import { Check, ExternalLink, MessageCircle, Palette, Store, Trash2 } from "lucide-react";
import { useState } from "react";
import Card from "@/components/ui/Card";
import { CURRENCIES, NICHES } from "@/lib/themes";
import type { Niche, StoreSettings } from "@/lib/types";
import { cn } from "@/lib/utils";
import { isValidPhone, normalizePhone } from "@/lib/whatsapp";
import ColorPicker from "./ColorPicker";
import NicheSwitcher from "./NicheSwitcher";
import { sanitizeSlug, validateSlug } from "./validation";
import { useOrigin } from "./useOrigin";

interface SettingsPanelProps {
  store: StoreSettings;
  update: (patch: Partial<StoreSettings>) => void;
  reset: () => void;
}

export default function SettingsPanel({ store, update, reset }: SettingsPanelProps) {
  const origin = useOrigin();
  const [slugDraft, setSlugDraft] = useState(store.slug);
  const [justSwitched, setJustSwitched] = useState<Niche | null>(null);

  const slugError = validateSlug(slugDraft);
  const phoneOk = isValidPhone(store.whatsapp);
  const phoneDigits = normalizePhone(store.whatsapp);

  const onSlugChange = (value: string) => {
    const clean = sanitizeSlug(value);
    setSlugDraft(clean);
    if (!validateSlug(clean)) update({ slug: clean });
  };

  const onNicheChange = (niche: Niche) => {
    if (niche === store.niche) return;
    update({ niche });
    setJustSwitched(niche);
  };

  const onReset = () => {
    if (window.confirm("سيتم حذف إعدادات المتجر وجميع المنتجات نهائياً من هذا المتصفح. هل أنت متأكد؟")) {
      reset();
    }
  };

  return (
    <div className="space-y-6">
      {/* Theme / niche */}
      <Card
        title="النشاط والثيم"
        description="يغيّر تخطيط المتجر العام وطريقة الطلب تلقائياً، دون أن تفقد أي منتج."
        icon={<Store size={20} />}
      >
        <NicheSwitcher value={store.niche} onChange={onNicheChange} detailed={false} />

        {justSwitched && (
          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-slate-50 px-4 py-3 text-sm">
            <span className="flex items-center gap-2 font-bold text-slate-700">
              <Check size={16} className="text-emerald-500" />
              تم تفعيل «{NICHES[justSwitched].title}»
            </span>
            {store.primaryColor.toLowerCase() !== NICHES[justSwitched].defaultColor.toLowerCase() && (
              <button
                type="button"
                className="font-bold underline-offset-4 hover:underline"
                style={{ color: "var(--brand)" }}
                onClick={() => update({ primaryColor: NICHES[justSwitched].defaultColor })}
              >
                استخدام لون هذا الثيم الافتراضي
              </button>
            )}
          </div>
        )}
      </Card>

      {/* Brand identity */}
      <Card title="هوية المتجر" description="الاسم والعنوان الذي يظهر لعملائك." icon={<Store size={20} />}>
        <div className="grid gap-5 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="st-brand">اسم العلامة التجارية</label>
            <input
              id="st-brand"
              className="input"
              value={store.brandName}
              onChange={(e) => update({ brandName: e.target.value })}
              placeholder="اسم متجرك"
            />
          </div>
          <div>
            <label className="label" htmlFor="st-tagline">الوصف المختصر</label>
            <input
              id="st-tagline"
              className="input"
              value={store.tagline}
              onChange={(e) => update({ tagline: e.target.value })}
              placeholder="جملة قصيرة تصف متجرك"
            />
          </div>

          <div className="sm:col-span-2">
            <label className="label" htmlFor="st-slug">عنوان المتجر العام</label>
            <div
              dir="ltr"
              className={cn(
                "flex items-center rounded-2xl border bg-white shadow-sm focus-within:ring-4 focus-within:ring-[var(--brand-ring)]",
                slugError ? "border-rose-300" : "border-slate-200 focus-within:border-[var(--brand)]",
              )}
            >
              <span className="shrink-0 ps-4 text-sm text-slate-400">{origin || "https://your-site"}/</span>
              <input
                id="st-slug"
                className="w-full bg-transparent px-1 py-3 pe-4 text-sm outline-none"
                value={slugDraft}
                onChange={(e) => onSlugChange(e.target.value)}
                spellCheck={false}
              />
            </div>
            {slugError ? (
              <p className="mt-1.5 text-xs font-bold text-rose-500">{slugError}</p>
            ) : (
              <p className="hint">تغيير العنوان يغيّر رابط المتجر ورمز QR، أعد طباعة الرمز بعد التعديل.</p>
            )}
          </div>

          <div>
            <label className="label" htmlFor="st-currency">العملة</label>
            <select
              id="st-currency"
              className="input"
              value={store.currency}
              onChange={(e) => update({ currency: e.target.value })}
            >
              {CURRENCIES.map((c) => (
                <option key={c.symbol} value={c.symbol}>
                  {c.label}
                </option>
              ))}
            </select>
          </div>
        </div>
      </Card>

      {/* WhatsApp */}
      <Card
        title="استقبال الطلبات عبر واتساب"
        description="الرقم الذي ستصله رسائل الطلبات من عملائك."
        icon={<MessageCircle size={20} />}
      >
        <label className="label" htmlFor="st-wa">رقم واتساب</label>
        <div className="flex flex-col gap-3 sm:flex-row">
          <input
            id="st-wa"
            dir="ltr"
            inputMode="tel"
            className={cn("input flex-1 text-left", !phoneOk && store.whatsapp && "!border-rose-300")}
            value={store.whatsapp}
            onChange={(e) => update({ whatsapp: e.target.value })}
            placeholder="966501234567"
          />
          {phoneOk && (
            <a
              href={`https://wa.me/${phoneDigits}`}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-ghost shrink-0"
            >
              <ExternalLink size={15} />
              جرّب الرقم
            </a>
          )}
        </div>
        {phoneOk ? (
          <p className="mt-2 flex items-center gap-1.5 text-xs font-bold text-emerald-600">
            <Check size={14} />
            سيتم إرسال الطلبات إلى{" "}
            <span dir="ltr" className="font-mono">+{phoneDigits}</span>
          </p>
        ) : (
          <p className="mt-2 text-xs font-bold text-rose-500">
            أدخل رقماً دولياً صحيحاً (8 إلى 15 رقماً)، مثل 966501234567.
          </p>
        )}
      </Card>

      {/* Colour */}
      <Card title="اللون الأساسي" description="يُطبَّق على الأزرار والعناصر المميزة في متجرك." icon={<Palette size={20} />}>
        <ColorPicker
          value={store.primaryColor}
          onChange={(hex) => update({ primaryColor: hex })}
          swatches={NICHES[store.niche].swatches}
        />
      </Card>

      {/* Danger zone */}
      <Card className="!border-rose-100">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="font-extrabold text-rose-600">منطقة الخطر</h2>
            <p className="mt-0.5 text-sm text-slate-500">حذف المتجر وبدء الإعداد من جديد.</p>
          </div>
          <button
            type="button"
            onClick={onReset}
            className="btn border border-rose-200 bg-rose-50 text-rose-600 hover:bg-rose-100"
          >
            <Trash2 size={16} />
            حذف المتجر
          </button>
        </div>
      </Card>
    </div>
  );
}
