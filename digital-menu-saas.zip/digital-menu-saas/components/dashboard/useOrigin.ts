"use client";

import { useEffect, useState } from "react";

/** The current site origin (empty during SSR / first render). */
export function useOrigin(): string {
  const [origin, setOrigin] = useState("");
  useEffect(() => {
    setOrigin(window.location.origin);
  }, []);
  return origin;
}
