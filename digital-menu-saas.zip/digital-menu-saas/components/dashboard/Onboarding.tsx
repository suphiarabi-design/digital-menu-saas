"use client";

import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, ArrowRight, Rocket } from "lucide-react";
import { useState } from "react";
import Logo from "@/components/ui/Logo";
import { sampleCatalogue } from "@/lib/seed";
import { NICHES } from "@/lib/themes";
import type { Niche, Product, StoreSettings } from "@/lib/types";
import { brandVars, cn, slugify } from "@/lib/utils";
import { isValidPhone } from "@/lib/whatsapp";
import ColorPicker from "./ColorPicker";
import NicheSwitcher from "./NicheSwitcher";
import { sanitizeSlug, validateSlug } from "./validation";
import { useOrigin } from "./useOrigin";

const DEFAULT_TAGLINE: Record<Niche, string> = {
  food: "أشهى المأكولات والمشروبات",
  cosmetics: "جمالك يبدأ من هنا",
  retail: "كل ما تحتاجه في مكان واحد",
};

interface OnboardingProps {
  onComplete: (store: StoreSettings) => void;
}

interface Errors {
  brandName?: string;
  slug?: string;
  whatsapp?: string;
}

/** Two-step store setup: pick the niche, then brand details. */
export default function Onboarding({ onComplete }: OnboardingProps) {
  const origin = useOrigin();
  const [step, setStep] = useState<0 | 1>(0);
  const [niche, setNiche] = useState<Niche>("food");
  const [brandName, setBrandName] = useState("");
  const [slugDraft, setSlugDraft] = useState<string | null>(null);
  const [whatsapp, setWhatsapp] = useState("");
  const [color, setColor] = useState(NICHES.food.defaultColor);
  const [withSamples, setWithSamples] = useState(true);
  const [errors, setErrors] = useState<Errors>({});

  const slug = slugDraft ?? slugify(brandName);
  const config = NICHES[niche];

  const pickNiche = (n: Niche) => {
    setNiche(n);
    setColor(NICHES[n].defaultColor);
  };

  const finish = () => {
    const next: Errors = {};
    if (!brandName.trim()) next.brandName = "اكتب اسم علامتك التجارية.";
    const slugError = validateSlug(slug);
    if (slugError) next.slug = slugError;
    if (!isValidPhone(whatsapp)) {
      next.whatsapp = "أدخل رقم واتساب صحيحاً بالصيغة الدولية، مثال: 966501234567";
    }
    setErrors(next);
    if (Object.keys(next).length > 0) return;

    const catalogue: { categories: string[]; products: Product[] } = withSamples
      ? sampleCatalogue(niche)
      : { categories: [], products: [] };

    onComplete({
      slug,
      brandName: brandName.trim(),
      tagline: DEFAULT_TAGLINE[niche],
      whatsapp: whatsapp.trim(),
      primaryColor: color,
      niche,
      currency: "ر.س",
      categories: catalogue.categories,
      products: catalogue.products,
      updatedAt: Date.now(),
    });
  };

  return (
    <div className="aurora min-h-dvh" style={brandVars(color)}>
      <header className="mx-auto flex max-w-5xl items-center justify-between px-5 py-6">
        <Logo />
        <div className="flex items-center gap-2" aria-label={`الخطوة ${step + 1} من 2`}>
          {[0, 1].map((i) => (
            <span
              key={i}
              className={cn(
                "h-2 rounded-full transition-all duration-300",
                i === step ? "w-8" : "w-2 bg-slate-300",
              )}
              style={i === step ? { background: "var(--brand)" } : undefined}
            />
          ))}
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-5 pb-16">
        <AnimatePresence mode="wait">
          {step === 0 ? (
            <motion.section
              key="step-0"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ duration: 0.3 }}
            >
              <div className="mx-auto max-w-xl text-center">
                <h1 className="text-balance text-3xl font-extrabold leading-snug sm:text-4xl">
                  ما نوع نشاطك التجاري؟
                </h1>
                <p className="mt-3 leading-8 text-slate-600">
                  سنجهّز لك الثيم المناسب تلقائياً، ويمكنك تغييره في أي وقت من لوحة التحكم.
                </p>
              </div>

              <div className="mt-10">
                <NicheSwitcher value={niche} onChange={pickNiche} />
              </div>

              <div className="mt-10 flex justify-center">
                <button type="button" onClick={() => setStep(1)} className="btn btn-brand !px-10 !py-4 text-base">
                  التالي
                  <ArrowLeft size={18} />
                </button>
              </div>
            </motion.section>
          ) : (
            <motion.section
              key="step-1"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ duration: 0.3 }}
              className="mx-auto max-w-xl"
            >
              <div className="text-center">
                <span className="text-5xl">{config.emoji}</span>
                <h1 className="mt-3 text-3xl font-extrabold">بيانات {config.label}</h1>
                <p className="mt-2 text-slate-600">معلومات بسيطة وينطلق متجرك.</p>
              </div>

              <div className="mt-8 space-y-5 rounded-[28px] border border-white bg-white/80 p-6 shadow-soft backdrop-blur sm:p-8">
                <div>
                  <label className="label" htmlFor="ob-brand">اسم العلامة التجارية</label>
                  <input
                    id="ob-brand"
                    className="input"
                    placeholder="مثال: كافيه الدار"
                    value={brandName}
                    onChange={(e) => {
                      setBrandName(e.target.value);
                      setErrors((er) => ({ ...er, brandName: undefined }));
                    }}
                  />
                  {errors.brandName && <p className="mt-1.5 text-xs font-bold text-rose-500">{errors.brandName}</p>}
                </div>

                <div>
                  <label className="label" htmlFor="ob-slug">عنوان المتجر</label>
                  <div dir="ltr" className="flex items-center rounded-2xl border border-slate-200 bg-white shadow-sm focus-within:border-[var(--brand)] focus-within:ring-4 focus-within:ring-[var(--brand-ring)]">
                    <span className="shrink-0 ps-4 text-sm text-slate-400">{origin || "https://your-site"}/</span>
                    <input
                      id="ob-slug"
                      className="w-full bg-transparent px-1 py-3 pe-4 text-sm outline-none"
                      placeholder="my-store"
                      value={slug}
                      onChange={(e) => {
                        setSlugDraft(sanitizeSlug(e.target.value));
                        setErrors((er) => ({ ...er, slug: undefined }));
                      }}
                    />
                  </div>
                  {errors.slug && <p className="mt-1.5 text-xs font-bold text-rose-500">{errors.slug}</p>}
                  {!errors.slug && <p className="hint">أحرف إنجليزية وأرقام وشرطات فقط. هذا هو رابط متجرك العام.</p>}
                </div>

                <div>
                  <label className="label" htmlFor="ob-wa">رقم واتساب لاستقبال الطلبات</label>
                  <input
                    id="ob-wa"
                    dir="ltr"
                    inputMode="tel"
                    className="input text-left"
                    placeholder="966501234567"
                    value={whatsapp}
                    onChange={(e) => {
                      setWhatsapp(e.target.value);
                      setErrors((er) => ({ ...er, whatsapp: undefined }));
                    }}
                  />
                  {errors.whatsapp && <p className="mt-1.5 text-xs font-bold text-rose-500">{errors.whatsapp}</p>}
                  {!errors.whatsapp && <p className="hint">بالصيغة الدولية بدون + أو أصفار، مثل 966501234567.</p>}
                </div>

                <div>
                  <p className="label">اللون الأساسي</p>
                  <ColorPicker value={color} onChange={setColor} swatches={config.swatches} />
                </div>

                <label className="flex cursor-pointer items-start gap-3 rounded-2xl bg-slate-50 p-4">
                  <input
                    type="checkbox"
                    checked={withSamples}
                    onChange={(e) => setWithSamples(e.target.checked)}
                    className="mt-1 h-4 w-4 accent-[var(--brand)]"
                  />
                  <span>
                    <span className="block text-sm font-bold">ابدأ بمنتجات نموذجية</span>
                    <span className="mt-0.5 block text-xs leading-6 text-slate-500">
                      نضيف فئات ومنتجات تجريبية تناسب نشاطك لتشاهد المتجر مكتملاً، ويمكنك حذفها أو تعديلها.
                    </span>
                  </span>
                </label>
              </div>

              <div className="mt-8 flex items-center justify-between gap-3">
                <button type="button" onClick={() => setStep(0)} className="btn btn-ghost">
                  <ArrowRight size={16} />
                  رجوع
                </button>
                <button type="button" onClick={finish} className="btn btn-brand !px-8 !py-3.5 text-base">
                  <Rocket size={18} />
                  إطلاق متجري
                </button>
              </div>
            </motion.section>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
