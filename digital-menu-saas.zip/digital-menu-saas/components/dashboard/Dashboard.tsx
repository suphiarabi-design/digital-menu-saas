"use client";

import { AnimatePresence, motion } from "framer-motion";
import { ExternalLink, Package, QrCode, Settings } from "lucide-react";
import Link from "next/link";
import { useState, type ComponentType } from "react";
import Logo from "@/components/ui/Logo";
import { useMerchantStore } from "@/lib/store";
import { NICHES } from "@/lib/themes";
import { brandVars, cn } from "@/lib/utils";
import Onboarding from "./Onboarding";
import ProductManager from "./ProductManager";
import QRPanel from "./QRPanel";
import SettingsPanel from "./SettingsPanel";

type TabId = "settings" | "products" | "qr";

const TABS: { id: TabId; label: string; icon: ComponentType<{ size?: number }> }[] = [
  { id: "settings", label: "الإعدادات والثيم", icon: Settings },
  { id: "products", label: "المنتجات", icon: Package },
  { id: "qr", label: "رمز QR", icon: QrCode },
];

export default function Dashboard() {
  const { store, ready, save, update, reset } = useMerchantStore();
  const [tab, setTab] = useState<TabId>("settings");

  if (!ready) {
    return (
      <div className="aurora grid min-h-dvh place-items-center" aria-busy="true">
        <div className="skeleton h-16 w-16 rounded-3xl" />
      </div>
    );
  }

  if (!store) return <Onboarding onComplete={save} />;

  const niche = NICHES[store.niche];

  return (
    <div className="aurora min-h-dvh pb-24 md:pb-12" style={brandVars(store.primaryColor)}>
      {/* Top bar */}
      <header className="sticky top-0 z-30 border-b border-white/60 bg-white/70 backdrop-blur-xl">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-5 py-3">
          <Logo />
          <div className="flex items-center gap-2">
            <span className="hidden items-center gap-2 rounded-full bg-white px-3.5 py-2 text-xs font-bold shadow-soft sm:inline-flex">
              <span>{niche.emoji}</span>
              {niche.label}
            </span>
            <Link
              href={`/${store.slug}`}
              target="_blank"
              className="btn btn-brand !py-2 text-xs sm:text-sm"
            >
              <ExternalLink size={15} />
              معاينة المتجر
            </Link>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-5 pt-8">
        <div className="mb-7">
          <h1 className="text-2xl font-extrabold sm:text-3xl">أهلاً بك في {store.brandName} 👋</h1>
          <p className="mt-1.5 text-sm text-slate-500">
            أي تغيير تحفظه هنا يظهر فوراً في متجرك العام.
          </p>
        </div>

        {/* Desktop tabs */}
        <nav
          className="mb-7 hidden gap-1 rounded-full border border-white bg-white/70 p-1.5 shadow-soft backdrop-blur md:inline-flex"
          aria-label="أقسام لوحة التحكم"
        >
          {TABS.map((t) => (
            <TabButton key={t.id} active={tab === t.id} onClick={() => setTab(t.id)} layout="top">
              <t.icon size={16} />
              {t.label}
            </TabButton>
          ))}
        </nav>

        <AnimatePresence mode="wait">
          <motion.div
            key={tab}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
          >
            {tab === "settings" && <SettingsPanel store={store} update={update} reset={reset} />}
            {tab === "products" && <ProductManager store={store} update={update} />}
            {tab === "qr" && <QRPanel store={store} />}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Mobile bottom tab bar */}
      <nav
        className="glass-strong fixed inset-x-3 bottom-safe z-40 flex rounded-full p-1.5 md:hidden"
        aria-label="أقسام لوحة التحكم"
      >
        {TABS.map((t) => (
          <TabButton key={t.id} active={tab === t.id} onClick={() => setTab(t.id)} layout="bottom">
            <t.icon size={18} />
            <span className="text-[11px]">{t.label}</span>
          </TabButton>
        ))}
      </nav>
    </div>
  );
}

function TabButton({
  active,
  onClick,
  layout,
  children,
}: {
  active: boolean;
  onClick: () => void;
  layout: "top" | "bottom";
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-current={active ? "page" : undefined}
      className={cn(
        "relative flex items-center justify-center rounded-full font-bold transition",
        layout === "top" ? "gap-2 px-5 py-2.5 text-sm" : "flex-1 flex-col gap-0.5 py-2",
        active ? "" : "text-slate-500 hover:text-slate-800",
      )}
      style={active ? { color: "var(--brand-contrast)" } : undefined}
    >
      {active && (
        <motion.span
          layoutId={`tab-pill-${layout}`}
          className="absolute inset-0 rounded-full shadow-soft"
          style={{ background: "var(--brand)" }}
          transition={{ type: "spring", stiffness: 420, damping: 34 }}
        />
      )}
      <span className="relative flex flex-col items-center gap-0.5 sm:flex-row sm:gap-2">{children}</span>
    </button>
  );
}
