"use client";

import { motion } from "framer-motion";
import { Check } from "lucide-react";
import { NICHE_LIST } from "@/lib/themes";
import type { Niche } from "@/lib/types";
import { brandVars, cn } from "@/lib/utils";

interface NicheSwitcherProps {
  value: Niche;
  onChange: (niche: Niche) => void;
  /** Show the longer description under each option. */
  detailed?: boolean;
}

/** Visual picker for the three storefront themes (Food / Cosmetics / Retail). */
export default function NicheSwitcher({ value, onChange, detailed = true }: NicheSwitcherProps) {
  return (
    <div role="radiogroup" aria-label="نوع النشاط" className="grid gap-4 md:grid-cols-3">
      {NICHE_LIST.map((n) => {
        const active = n.id === value;
        return (
          <button
            key={n.id}
            type="button"
            role="radio"
            aria-checked={active}
            onClick={() => onChange(n.id)}
            style={brandVars(n.defaultColor)}
            className={cn(
              "group relative overflow-hidden rounded-3xl border bg-white p-4 text-start transition duration-200",
              active
                ? "border-transparent shadow-lift"
                : "border-slate-200 hover:-translate-y-0.5 hover:border-slate-300 hover:shadow-soft",
            )}
          >
            {active && (
              <motion.span
                layoutId="niche-ring"
                className="pointer-events-none absolute inset-0 rounded-3xl ring-2 ring-inset"
                style={{ boxShadow: "inset 0 0 0 2px var(--brand)" }}
                transition={{ type: "spring", stiffness: 420, damping: 34 }}
              />
            )}

            <div className="flex items-center justify-between">
              <span
                className="grid h-11 w-11 place-items-center rounded-2xl text-2xl"
                style={{ background: "var(--brand-soft)" }}
              >
                {n.emoji}
              </span>
              <span
                className={cn(
                  "grid h-6 w-6 place-items-center rounded-full border transition",
                  active ? "border-transparent text-white" : "border-slate-300 text-transparent",
                )}
                style={active ? { background: "var(--brand)" } : undefined}
              >
                <Check size={14} strokeWidth={3} />
              </span>
            </div>

            <h3 className="mt-3 font-extrabold">{n.label}</h3>
            {detailed && (
              <p className="mt-1 text-xs leading-6 text-slate-500">{n.description}</p>
            )}

            <MiniLayout niche={n.id} />
          </button>
        );
      })}
    </div>
  );
}

/** Tiny wireframe that hints at each theme's layout. */
function MiniLayout({ niche }: { niche: Niche }) {
  const tint = "var(--brand-soft)";
  const solid = "var(--brand)";

  if (niche === "food") {
    return (
      <div className="mt-4 space-y-1.5 rounded-2xl bg-slate-50 p-2.5" aria-hidden>
        {[0, 1, 2].map((i) => (
          <div key={i} className="flex items-center gap-2 rounded-xl bg-white p-1.5 shadow-sm">
            <span className="h-6 w-6 rounded-lg" style={{ background: tint }} />
            <span className="h-1.5 flex-1 rounded-full bg-slate-200" />
            <span className="h-4 w-4 rounded-full" style={{ background: solid }} />
          </div>
        ))}
      </div>
    );
  }

  if (niche === "cosmetics") {
    return (
      <div className="mt-4 grid grid-cols-2 gap-2 rounded-2xl bg-slate-50 p-2.5" aria-hidden>
        {[0, 1].map((i) => (
          <div key={i}>
            <span className="block aspect-[4/5] rounded-xl" style={{ background: tint }} />
            <span className="mt-1.5 block h-1.5 w-2/3 rounded-full bg-slate-200" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="mt-4 grid grid-cols-3 gap-1.5 rounded-2xl bg-slate-50 p-2.5" aria-hidden>
      {[0, 1, 2, 3, 4, 5].map((i) => (
        <div key={i} className="rounded-lg bg-white p-1 shadow-sm">
          <span className="block aspect-square rounded-md" style={{ background: tint }} />
          <span className="mt-1 block h-1 w-full rounded-full bg-slate-200" />
          <span className="mt-1 block h-1.5 w-1/2 rounded-full" style={{ background: solid }} />
        </div>
      ))}
    </div>
  );
}
