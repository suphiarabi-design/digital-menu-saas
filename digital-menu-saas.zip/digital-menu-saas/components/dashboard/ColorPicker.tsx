"use client";

import { Check } from "lucide-react";
import { useEffect, useState } from "react";
import { cn, isValidHex } from "@/lib/utils";

interface ColorPickerProps {
  value: string;
  onChange: (hex: string) => void;
  swatches: string[];
}

/** Preset swatches + native colour input + hex field. */
export default function ColorPicker({ value, onChange, swatches }: ColorPickerProps) {
  const [text, setText] = useState(value);

  useEffect(() => {
    setText(value);
  }, [value]);

  const commitText = (raw: string) => {
    setText(raw);
    const hex = raw.startsWith("#") ? raw : `#${raw}`;
    if (/^#[0-9a-fA-F]{6}$/.test(hex)) onChange(hex.toLowerCase());
  };

  const nativeValue = isValidHex(value) && value.length === 7 ? value : "#6d5efc";
  const invalid = text.length > 0 && !isValidHex(text.startsWith("#") ? text : `#${text}`);

  return (
    <div>
      <div className="flex flex-wrap items-center gap-2.5">
        {swatches.map((hex) => {
          const active = value.toLowerCase() === hex.toLowerCase();
          return (
            <button
              key={hex}
              type="button"
              onClick={() => onChange(hex)}
              aria-label={`اللون ${hex}`}
              aria-pressed={active}
              className={cn(
                "grid h-10 w-10 place-items-center rounded-full ring-offset-2 transition active:scale-90",
                active ? "ring-2 ring-slate-900" : "hover:scale-110",
              )}
              style={{ background: hex }}
            >
              {active && <Check size={16} className="text-white drop-shadow" strokeWidth={3} />}
            </button>
          );
        })}

        <label
          className="relative grid h-10 w-10 cursor-pointer place-items-center overflow-hidden rounded-full border-2 border-dashed border-slate-300 text-lg text-slate-400 transition hover:border-slate-400"
          title="اختر لوناً مخصصاً"
        >
          +
          <input
            type="color"
            value={nativeValue}
            onChange={(e) => onChange(e.target.value.toLowerCase())}
            className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
            aria-label="اختيار لون مخصص"
          />
        </label>
      </div>

      <div className="mt-4 flex items-center gap-3">
        <span
          className="h-11 w-11 shrink-0 rounded-2xl border border-black/10 shadow-sm"
          style={{ background: nativeValue }}
          aria-hidden
        />
        <input
          dir="ltr"
          value={text}
          onChange={(e) => commitText(e.target.value)}
          maxLength={7}
          spellCheck={false}
          className={cn("input max-w-[160px] text-left font-mono uppercase", invalid && "!border-rose-400")}
          aria-label="رمز اللون بصيغة HEX"
          placeholder="#6D5EFC"
        />
      </div>
      {invalid && <p className="mt-1.5 text-xs font-bold text-rose-500">رمز اللون غير صحيح.</p>}
    </div>
  );
}
