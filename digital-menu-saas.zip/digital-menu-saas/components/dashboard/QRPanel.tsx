"use client";

import { Check, Copy, Download, ExternalLink, QrCode } from "lucide-react";
import QRCode from "qrcode";
import { useEffect, useRef, useState } from "react";
import Card from "@/components/ui/Card";
import type { StoreSettings } from "@/lib/types";
import { qrDarkColor } from "@/lib/utils";
import { useOrigin } from "./useOrigin";

const PREVIEW_SIZE = 560;
const DOWNLOAD_SIZE = 1200;

export default function QRPanel({ store }: { store: StoreSettings }) {
  const origin = useOrigin();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [copied, setCopied] = useState(false);
  const [useBrandColor, setUseBrandColor] = useState(true);
  const [error, setError] = useState(false);

  const url = origin ? `${origin}/${store.slug}` : "";
  const dark = useBrandColor ? qrDarkColor(store.primaryColor) : "#111827";

  // Render the preview whenever the link or colour changes.
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !url) return;
    let cancelled = false;
    QRCode.toCanvas(canvas, url, {
      width: PREVIEW_SIZE,
      margin: 2,
      errorCorrectionLevel: "M",
      color: { dark, light: "#ffffff" },
    })
      .then(() => {
        if (!cancelled) setError(false);
      })
      .catch(() => {
        if (!cancelled) setError(true);
      });
    return () => {
      cancelled = true;
    };
  }, [url, dark]);

  const download = async () => {
    if (!url) return;
    try {
      const dataUrl = await QRCode.toDataURL(url, {
        width: DOWNLOAD_SIZE,
        margin: 4,
        errorCorrectionLevel: "M",
        color: { dark, light: "#ffffff" },
      });
      const a = document.createElement("a");
      a.href = dataUrl;
      a.download = `qr-${store.slug}.png`;
      document.body.appendChild(a);
      a.click();
      a.remove();
    } catch {
      setError(true);
    }
  };

  const copy = async () => {
    if (!url) return;
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      window.prompt("انسخ الرابط:", url);
    }
  };

  return (
    <Card
      title="رمز QR لمتجرك"
      description="اطبعه على الطاولات أو الواجهة أو الفواتير ليصل عميلك لمتجرك بمسحة واحدة."
      icon={<QrCode size={20} />}
    >
      <div className="grid items-center gap-8 md:grid-cols-[auto_1fr]">
        <div className="mx-auto">
          <div className="rounded-[32px] bg-white p-4 shadow-lift ring-1 ring-black/5">
            <canvas
              ref={canvasRef}
              aria-label={`رمز QR لرابط ${url}`}
              className="h-56 w-56 rounded-2xl sm:h-64 sm:w-64"
            />
          </div>
          <p className="mt-4 text-center text-sm font-extrabold">{store.brandName}</p>
          <p className="text-center text-xs text-slate-400">امسح للطلب</p>
        </div>

        <div className="min-w-0">
          <p className="label">رابط متجرك العام</p>
          <div
            dir="ltr"
            className="flex items-center gap-2 rounded-2xl border border-slate-200 bg-slate-50 py-2 pe-2 ps-4"
          >
            <span className="min-w-0 flex-1 truncate text-sm text-slate-600">
              {url || "…"}
            </span>
            <button
              type="button"
              onClick={copy}
              className="btn btn-ghost !px-3.5 !py-2 text-xs"
              aria-label="نسخ الرابط"
            >
              {copied ? <Check size={14} className="text-emerald-500" /> : <Copy size={14} />}
              {copied ? "تم النسخ" : "نسخ"}
            </button>
          </div>

          <label className="mt-5 flex cursor-pointer items-center gap-3">
            <input
              type="checkbox"
              checked={useBrandColor}
              onChange={(e) => setUseBrandColor(e.target.checked)}
              className="h-4 w-4 accent-[var(--brand)]"
            />
            <span className="text-sm font-bold">استخدام لون علامتي في الرمز</span>
          </label>
          <p className="hint">
            نُعتّم الألوان الفاتحة تلقائياً ليبقى الرمز قابلاً للمسح بسهولة.
          </p>

          {error && (
            <p role="alert" className="mt-3 text-xs font-bold text-rose-500">
              تعذّر إنشاء الرمز. تحقق من الرابط وحاول مجدداً.
            </p>
          )}

          <div className="mt-6 flex flex-wrap gap-3">
            <button type="button" onClick={download} disabled={!url} className="btn btn-brand">
              <Download size={16} />
              تحميل PNG عالي الدقة
            </button>
            <a
              href={url || undefined}
              target="_blank"
              rel="noopener noreferrer"
              aria-disabled={!url}
              className="btn btn-ghost"
            >
              <ExternalLink size={16} />
              فتح المتجر
            </a>
          </div>
        </div>
      </div>
    </Card>
  );
}
