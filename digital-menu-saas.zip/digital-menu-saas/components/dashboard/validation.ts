import { RESERVED_SLUGS } from "@/lib/brand";
import { DEMO_STORES } from "@/lib/seed";
import { SLUG_RE } from "@/lib/utils";

export function sanitizeSlug(value: string): string {
  return value.toLowerCase().replace(/[^a-z0-9-]/g, "").slice(0, 40);
}

/** Returns an Arabic error message, or "" when the slug is acceptable. */
export function validateSlug(slug: string): string {
  if (!slug) return "اكتب عنواناً للمتجر بالأحرف الإنجليزية.";
  if (!SLUG_RE.test(slug)) {
    return "من 3 إلى 40 حرفاً: أحرف إنجليزية صغيرة وأرقام وشرطات فقط، بدون شرطة في البداية أو النهاية.";
  }
  if (RESERVED_SLUGS.includes(slug) || slug in DEMO_STORES) {
    return "هذا العنوان محجوز، اختر عنواناً آخر.";
  }
  return "";
}
