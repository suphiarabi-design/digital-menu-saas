"use client";

import { Eye, EyeOff, Package, Pencil, Plus, Search, Tag, Trash2, X } from "lucide-react";
import { useMemo, useState } from "react";
import ProductImage from "@/components/storefront/ProductImage";
import Card from "@/components/ui/Card";
import Modal from "@/components/ui/Modal";
import { PRODUCT_EMOJIS } from "@/lib/themes";
import type { Product, StoreSettings } from "@/lib/types";
import { cn, formatPrice, toLatinDigits, uid } from "@/lib/utils";

interface ProductManagerProps {
  store: StoreSettings;
  update: (patch: Partial<StoreSettings>) => void;
}

interface Draft {
  id: string | null;
  name: string;
  description: string;
  price: string;
  category: string;
  newCategory: string;
  emoji: string;
  hue: number;
  imageUrl: string;
  sizes: string;
  badge: string;
  available: boolean;
}

const NEW_CATEGORY = "__new__";

function emptyDraft(store: StoreSettings): Draft {
  return {
    id: null,
    name: "",
    description: "",
    price: "",
    category: store.categories[0] ?? NEW_CATEGORY,
    newCategory: "",
    emoji: PRODUCT_EMOJIS[0],
    hue: Math.floor(Math.random() * 360),
    imageUrl: "",
    sizes: "",
    badge: "",
    available: true,
  };
}

function draftFrom(product: Product): Draft {
  return {
    id: product.id,
    name: product.name,
    description: product.description,
    price: String(product.price),
    category: product.category,
    newCategory: "",
    emoji: product.emoji,
    hue: product.hue,
    imageUrl: product.imageUrl ?? "",
    sizes: (product.sizes ?? []).join("، "),
    badge: product.badge ?? "",
    available: product.available,
  };
}

function parseSizes(raw: string): string[] {
  return raw
    .split(/[,،\n]/)
    .map((s) => s.trim())
    .filter(Boolean);
}

export default function ProductManager({ store, update }: ProductManagerProps) {
  const [draft, setDraft] = useState<Draft | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [filter, setFilter] = useState("all");
  const [query, setQuery] = useState("");
  const [newCat, setNewCat] = useState("");

  const sizeLabel = store.niche === "retail" ? "المقاسات" : "الأحجام أو الخيارات";

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return store.products.filter(
      (p) =>
        (filter === "all" || p.category === filter) &&
        (!q || p.name.toLowerCase().includes(q)),
    );
  }, [store.products, filter, query]);

  /* ----------------------------- products ----------------------------- */

  const openNew = () => {
    setErrors({});
    setDraft(emptyDraft(store));
  };

  const openEdit = (p: Product) => {
    setErrors({});
    setDraft(draftFrom(p));
  };

  const patchDraft = (p: Partial<Draft>) => setDraft((d) => (d ? { ...d, ...p } : d));

  const save = () => {
    if (!draft) return;
    const e: Record<string, string> = {};
    const price = Number(toLatinDigits(draft.price).replace(",", "."));
    const category =
      draft.category === NEW_CATEGORY ? draft.newCategory.trim() : draft.category;

    if (!draft.name.trim()) e.name = "اكتب اسم المنتج.";
    if (!draft.price.trim() || !Number.isFinite(price) || price < 0) {
      e.price = "أدخل سعراً صحيحاً.";
    }
    if (!category) e.category = "اختر فئة أو أنشئ فئة جديدة.";
    if (draft.imageUrl.trim() && !/^https?:\/\//i.test(draft.imageUrl.trim())) {
      e.imageUrl = "يجب أن يبدأ الرابط بـ http:// أو https://";
    }
    setErrors(e);
    if (Object.keys(e).length > 0) return;

    const sizes = parseSizes(draft.sizes);
    const product: Product = {
      id: draft.id ?? uid("p"),
      name: draft.name.trim(),
      description: draft.description.trim(),
      price,
      category,
      emoji: draft.emoji,
      hue: draft.hue,
      imageUrl: draft.imageUrl.trim() || undefined,
      sizes: sizes.length > 0 ? sizes : undefined,
      badge: draft.badge.trim() || undefined,
      available: draft.available,
    };

    const categories = store.categories.includes(category)
      ? store.categories
      : [...store.categories, category];
    const products = draft.id
      ? store.products.map((p) => (p.id === draft.id ? product : p))
      : [...store.products, product];

    update({ products, categories });
    setDraft(null);
  };

  const remove = (p: Product) => {
    if (!window.confirm(`حذف «${p.name}» نهائياً؟`)) return;
    update({ products: store.products.filter((x) => x.id !== p.id) });
  };

  const toggleAvailable = (p: Product) => {
    update({
      products: store.products.map((x) =>
        x.id === p.id ? { ...x, available: !x.available } : x,
      ),
    });
  };

  /* ---------------------------- categories ---------------------------- */

  const addCategory = () => {
    const name = newCat.trim();
    if (!name || store.categories.includes(name)) return;
    update({ categories: [...store.categories, name] });
    setNewCat("");
  };

  const removeCategory = (name: string) => {
    const count = store.products.filter((p) => p.category === name).length;
    if (count > 0) {
      window.alert(`لا يمكن حذف «${name}» لأنها تحتوي ${count} منتج. انقل المنتجات أو احذفها أولاً.`);
      return;
    }
    update({ categories: store.categories.filter((c) => c !== name) });
    if (filter === name) setFilter("all");
  };

  return (
    <div className="space-y-6">
      {/* Categories */}
      <Card title="الفئات" description="رتّب منتجاتك في فئات ليسهل تصفحها." icon={<Tag size={20} />}>
        <div className="flex flex-wrap gap-2">
          {store.categories.map((c) => (
            <span
              key={c}
              className="inline-flex items-center gap-1.5 rounded-full bg-slate-100 py-1.5 pe-2 ps-4 text-sm font-bold text-slate-700"
            >
              {c}
              <button
                type="button"
                onClick={() => removeCategory(c)}
                aria-label={`حذف الفئة ${c}`}
                className="grid h-6 w-6 place-items-center rounded-full text-slate-400 transition hover:bg-rose-100 hover:text-rose-600"
              >
                <X size={13} />
              </button>
            </span>
          ))}
          {store.categories.length === 0 && (
            <p className="text-sm text-slate-400">لا توجد فئات بعد. أضف أول فئة.</p>
          )}
        </div>
        <form
          className="mt-4 flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            addCategory();
          }}
        >
          <input
            className="input max-w-xs"
            placeholder="اسم فئة جديدة"
            value={newCat}
            onChange={(e) => setNewCat(e.target.value)}
            aria-label="اسم الفئة الجديدة"
          />
          <button type="submit" className="btn btn-dark shrink-0" disabled={!newCat.trim()}>
            <Plus size={16} />
            إضافة
          </button>
        </form>
      </Card>

      {/* Products */}
      <Card
        title={`المنتجات (${store.products.length})`}
        description="أضف منتجاتك وعدّل أسعارها وتوفرها في أي وقت."
        icon={<Package size={20} />}
      >
        <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search size={16} className="pointer-events-none absolute start-4 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              className="input !ps-11"
              placeholder="ابحث في المنتجات…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              aria-label="بحث"
            />
          </div>
          <select
            className="input sm:max-w-[200px]"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            aria-label="تصفية حسب الفئة"
          >
            <option value="all">كل الفئات</option>
            {store.categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
          <button type="button" onClick={openNew} className="btn btn-brand shrink-0">
            <Plus size={16} />
            منتج جديد
          </button>
        </div>

        {store.products.length === 0 ? (
          <div className="rounded-3xl border-2 border-dashed border-slate-200 py-14 text-center">
            <p className="text-4xl">📦</p>
            <p className="mt-3 font-extrabold">لا توجد منتجات بعد</p>
            <p className="mt-1 text-sm text-slate-500">ابدأ بإضافة أول منتج في متجرك.</p>
            <button type="button" onClick={openNew} className="btn btn-brand mt-5">
              <Plus size={16} />
              أضف منتجاً
            </button>
          </div>
        ) : visible.length === 0 ? (
          <p className="py-10 text-center text-sm text-slate-400">لا توجد منتجات مطابقة.</p>
        ) : (
          <ul className="divide-y divide-slate-100">
            {visible.map((p) => (
              <li key={p.id} className="flex items-center gap-3 py-3.5 sm:gap-4">
                <ProductImage
                  product={p}
                  className={cn("h-16 w-16 shrink-0 rounded-2xl", !p.available && "opacity-50")}
                  emojiClassName="text-2xl"
                />
                <div className="min-w-0 flex-1">
                  <p className="flex items-center gap-2">
                    <span className="truncate font-extrabold">{p.name}</span>
                    {!p.available && (
                      <span className="shrink-0 rounded-full bg-slate-200 px-2 py-0.5 text-[10px] font-extrabold text-slate-600">
                        غير متوفر
                      </span>
                    )}
                  </p>
                  <p className="mt-0.5 truncate text-xs text-slate-500">
                    {p.category}
                    {p.sizes && p.sizes.length > 0 ? ` · ${p.sizes.length} خيارات` : ""}
                  </p>
                  <p className="mt-1 text-sm font-extrabold" style={{ color: "var(--brand)" }}>
                    {formatPrice(p.price, store.currency)}
                  </p>
                </div>
                <div className="flex shrink-0 items-center gap-0.5">
                  <IconButton
                    label={p.available ? "إخفاء من المتجر (نفد)" : "إظهار كمتوفر"}
                    onClick={() => toggleAvailable(p)}
                  >
                    {p.available ? <Eye size={17} /> : <EyeOff size={17} />}
                  </IconButton>
                  <IconButton label="تعديل" onClick={() => openEdit(p)}>
                    <Pencil size={17} />
                  </IconButton>
                  <IconButton label="حذف" danger onClick={() => remove(p)}>
                    <Trash2 size={17} />
                  </IconButton>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Card>

      {/* Editor */}
      <Modal
        open={draft !== null}
        onClose={() => setDraft(null)}
        title={draft?.id ? "تعديل المنتج" : "منتج جديد"}
        maxWidth="max-w-2xl"
      >
        {draft && (
          <form
            className="space-y-5 p-6"
            onSubmit={(e) => {
              e.preventDefault();
              save();
            }}
          >
            {/* Preview + placeholder picker */}
            <div className="flex items-center gap-4 rounded-3xl bg-slate-50 p-4">
              <ProductImage
                product={{
                  name: draft.name || "معاينة",
                  emoji: draft.emoji,
                  hue: draft.hue,
                  imageUrl: draft.imageUrl.trim() || undefined,
                }}
                className="h-24 w-24 shrink-0 rounded-3xl"
                emojiClassName="text-4xl"
              />
              <div className="min-w-0 flex-1">
                <p className="mb-2 text-xs font-bold text-slate-500">صورة بديلة (إيموجي ولون)</p>
                <div className="flex flex-wrap gap-1">
                  {PRODUCT_EMOJIS.map((em) => (
                    <button
                      key={em}
                      type="button"
                      onClick={() => patchDraft({ emoji: em })}
                      aria-label={`إيموجي ${em}`}
                      aria-pressed={draft.emoji === em}
                      className={cn(
                        "grid h-8 w-8 place-items-center rounded-lg text-lg transition hover:bg-white",
                        draft.emoji === em && "bg-white shadow-sm ring-2 ring-slate-900",
                      )}
                    >
                      {em}
                    </button>
                  ))}
                </div>
                <input
                  type="range"
                  min={0}
                  max={360}
                  value={draft.hue}
                  onChange={(e) => patchDraft({ hue: Number(e.target.value) })}
                  aria-label="درجة اللون"
                  className="mt-3 h-2 w-full cursor-pointer appearance-none rounded-full"
                  style={{
                    background:
                      "linear-gradient(to right, hsl(0 85% 80%), hsl(60 85% 80%), hsl(120 85% 80%), hsl(180 85% 80%), hsl(240 85% 80%), hsl(300 85% 80%), hsl(360 85% 80%))",
                  }}
                />
              </div>
            </div>

            <div className="grid gap-5 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <label className="label" htmlFor="pd-name">اسم المنتج</label>
                <input
                  id="pd-name"
                  className="input"
                  value={draft.name}
                  onChange={(e) => patchDraft({ name: e.target.value })}
                  autoFocus
                />
                {errors.name && <p className="mt-1.5 text-xs font-bold text-rose-500">{errors.name}</p>}
              </div>

              <div>
                <label className="label" htmlFor="pd-price">السعر ({store.currency})</label>
                <input
                  id="pd-price"
                  dir="ltr"
                  inputMode="decimal"
                  className="input text-left"
                  value={draft.price}
                  onChange={(e) => patchDraft({ price: e.target.value })}
                  placeholder="0.00"
                />
                {errors.price && <p className="mt-1.5 text-xs font-bold text-rose-500">{errors.price}</p>}
              </div>

              <div>
                <label className="label" htmlFor="pd-cat">الفئة</label>
                <select
                  id="pd-cat"
                  className="input"
                  value={draft.category}
                  onChange={(e) => patchDraft({ category: e.target.value })}
                >
                  {store.categories.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                  <option value={NEW_CATEGORY}>＋ فئة جديدة…</option>
                </select>
                {draft.category === NEW_CATEGORY && (
                  <input
                    className="input mt-2"
                    placeholder="اسم الفئة الجديدة"
                    value={draft.newCategory}
                    onChange={(e) => patchDraft({ newCategory: e.target.value })}
                    aria-label="اسم الفئة الجديدة"
                  />
                )}
                {errors.category && <p className="mt-1.5 text-xs font-bold text-rose-500">{errors.category}</p>}
              </div>

              <div className="sm:col-span-2">
                <label className="label" htmlFor="pd-desc">الوصف</label>
                <textarea
                  id="pd-desc"
                  rows={3}
                  className="input resize-none"
                  value={draft.description}
                  onChange={(e) => patchDraft({ description: e.target.value })}
                  placeholder="وصف مختصر يظهر للعميل"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="label" htmlFor="pd-sizes">
                  {sizeLabel} <span className="font-normal text-slate-400">(اختياري)</span>
                </label>
                <input
                  id="pd-sizes"
                  className="input"
                  value={draft.sizes}
                  onChange={(e) => patchDraft({ sizes: e.target.value })}
                  placeholder={store.niche === "retail" ? "S، M، L، XL" : "صغير، وسط، كبير"}
                />
                <p className="hint">افصل بين الخيارات بفاصلة. سيُطلب من العميل اختيار واحد منها.</p>
              </div>

              <div>
                <label className="label" htmlFor="pd-badge">
                  شارة <span className="font-normal text-slate-400">(اختياري)</span>
                </label>
                <input
                  id="pd-badge"
                  className="input"
                  value={draft.badge}
                  onChange={(e) => patchDraft({ badge: e.target.value })}
                  placeholder="الأكثر طلباً"
                  maxLength={20}
                />
              </div>

              <div>
                <label className="label" htmlFor="pd-img">
                  رابط صورة <span className="font-normal text-slate-400">(اختياري)</span>
                </label>
                <input
                  id="pd-img"
                  dir="ltr"
                  className="input text-left"
                  value={draft.imageUrl}
                  onChange={(e) => patchDraft({ imageUrl: e.target.value })}
                  placeholder="https://…"
                />
                {errors.imageUrl && <p className="mt-1.5 text-xs font-bold text-rose-500">{errors.imageUrl}</p>}
              </div>
            </div>

            <label className="flex cursor-pointer items-center gap-3 rounded-2xl bg-slate-50 p-4">
              <input
                type="checkbox"
                checked={draft.available}
                onChange={(e) => patchDraft({ available: e.target.checked })}
                className="h-4 w-4 accent-[var(--brand)]"
              />
              <span className="text-sm font-bold">متوفر للطلب</span>
            </label>

            <div className="flex justify-end gap-3 pt-1">
              <button type="button" onClick={() => setDraft(null)} className="btn btn-ghost">
                إلغاء
              </button>
              <button type="submit" className="btn btn-brand !px-8">
                {draft.id ? "حفظ التعديلات" : "إضافة المنتج"}
              </button>
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
}

function IconButton({
  children,
  label,
  onClick,
  danger,
}: {
  children: React.ReactNode;
  label: string;
  onClick: () => void;
  danger?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      title={label}
      className={cn(
        "grid h-9 w-9 place-items-center rounded-full text-slate-500 transition",
        danger ? "hover:bg-rose-50 hover:text-rose-600" : "hover:bg-slate-100 hover:text-slate-900",
      )}
    >
      {children}
    </button>
  );
}
