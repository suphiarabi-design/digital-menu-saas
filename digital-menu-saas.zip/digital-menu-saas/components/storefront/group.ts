import type { Product, StoreSettings } from "@/lib/types";

export interface CategoryGroup {
  name: string;
  items: Product[];
}

/** Groups products by category, keeping the merchant's category order. */
export function groupByCategory(
  store: Pick<StoreSettings, "categories" | "products">,
): CategoryGroup[] {
  const known = new Set(store.categories);
  const groups: CategoryGroup[] = store.categories
    .map((name) => ({
      name,
      items: store.products.filter((p) => p.category === name),
    }))
    .filter((g) => g.items.length > 0);

  const rest = store.products.filter((p) => !known.has(p.category));
  if (rest.length > 0) groups.push({ name: "أخرى", items: rest });
  return groups;
}
