import type { CartApi } from "@/lib/cart";
import type { Product, StoreSettings } from "@/lib/types";

/** Contract every niche theme implements. */
export interface ThemeProps {
  store: StoreSettings;
  cart: CartApi;
  /** Open the product details sheet. */
  onOpenProduct: (product: Product) => void;
  /** Add one unit instantly (opens the sheet when the product needs a size). */
  onQuickAdd: (product: Product) => void;
  onOpenCart: () => void;
}
