"use client";

import { useEffect, useState } from "react";
import type { Product } from "@/lib/types";
import { cn } from "@/lib/utils";

interface ProductImageProps {
  product: Pick<Product, "name" | "emoji" | "hue" | "imageUrl">;
  className?: string;
  emojiClassName?: string;
}

/**
 * Shows the product photo when an image URL exists, otherwise a generated
 * gradient placeholder with an emoji (so every store looks good from day one).
 */
export default function ProductImage({
  product,
  className,
  emojiClassName = "text-5xl",
}: ProductImageProps) {
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    setFailed(false);
  }, [product.imageUrl]);

  if (product.imageUrl && !failed) {
    return (
      // eslint-disable-next-line @next/next/no-img-element
      <img
        src={product.imageUrl}
        alt={product.name}
        loading="lazy"
        onError={() => setFailed(true)}
        className={cn("object-cover", className)}
      />
    );
  }

  const h = product.hue;
  return (
    <div
      aria-hidden
      className={cn("relative grid place-items-center overflow-hidden", className)}
      style={{
        background: `linear-gradient(135deg, hsl(${h} 85% 94%), hsl(${(h + 28) % 360} 80% 82%))`,
      }}
    >
      <span className="absolute -start-6 -top-6 h-24 w-24 rounded-full bg-white/40 blur-xl" />
      <span
        className="absolute -bottom-8 -end-4 h-28 w-28 rounded-full blur-2xl"
        style={{ background: `hsl(${h} 90% 75% / 0.5)` }}
      />
      <span className={cn("relative drop-shadow-sm", emojiClassName)}>
        {product.emoji}
      </span>
    </div>
  );
}
