"use client";

import { AnimatePresence, motion } from "framer-motion";
import { ShoppingBag } from "lucide-react";
import { formatPrice } from "@/lib/utils";

interface FloatingCartProps {
  count: number;
  total: number;
  currency: string;
  hidden?: boolean;
  onOpen: () => void;
}

/** Sticky bottom cart bar: the "instant cart" for mobile shoppers. */
export default function FloatingCart({
  count,
  total,
  currency,
  hidden,
  onOpen,
}: FloatingCartProps) {
  return (
    <AnimatePresence>
      {count > 0 && !hidden && (
        <motion.div
          className="pointer-events-none fixed inset-x-0 bottom-safe z-40 flex justify-center px-4"
          initial={{ y: 120, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 120, opacity: 0 }}
          transition={{ type: "spring", damping: 26, stiffness: 320 }}
        >
          <motion.button
            type="button"
            onClick={onOpen}
            whileTap={{ scale: 0.97 }}
            className="btn-brand pointer-events-auto flex w-full max-w-md items-center justify-between rounded-full px-3 py-3 shadow-lift"
            aria-label="عرض السلة"
          >
            <span className="flex items-center gap-3">
              <span className="relative grid h-10 w-10 place-items-center rounded-full bg-white/20">
                <ShoppingBag size={20} />
                <motion.span
                  key={count}
                  initial={{ scale: 1.5 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", stiffness: 500, damping: 18 }}
                  className="absolute -end-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-white px-1 text-[11px] font-extrabold text-slate-900"
                >
                  {count}
                </motion.span>
              </span>
              <span className="text-sm font-extrabold">عرض السلة</span>
            </span>
            <span className="pe-3 text-sm font-extrabold">
              {formatPrice(total, currency)}
            </span>
          </motion.button>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
