"use client";

import { Minus, Plus, X } from "lucide-react";
import { useRef, useState } from "react";
import Modal from "@/components/ui/Modal";
import type { Product, StoreSettings } from "@/lib/types";
import { cn, formatPrice } from "@/lib/utils";
import ProductImage from "./ProductImage";

interface ProductSheetProps {
  product: Product | null;
  store: StoreSettings;
  onClose: () => void;
  onAdd: (product: Product, opts: { size?: string; qty: number }) => void;
}

/** Product details: large image, description, size picker and quantity. */
export default function ProductSheet({
  product,
  store,
  onClose,
  onAdd,
}: ProductSheetProps) {
  // Keep rendering the last product while the exit animation plays.
  const lastRef = useRef<Product | null>(null);
  if (product) lastRef.current = product;
  const shown = product ?? lastRef.current;

  return (
    <Modal open={product !== null} onClose={onClose} maxWidth="max-w-3xl">
      {shown && (
        <SheetBody
          key={shown.id}
          product={shown}
          store={store}
          onClose={onClose}
          onAdd={onAdd}
        />
      )}
    </Modal>
  );
}

function SheetBody({
  product,
  store,
  onClose,
  onAdd,
}: {
  product: Product;
  store: StoreSettings;
  onClose: () => void;
  onAdd: ProductSheetProps["onAdd"];
}) {
  const [size, setSize] = useState<string | null>(null);
  const [qty, setQty] = useState(1);
  const [needSize, setNeedSize] = useState(false);

  const sizes = product.sizes ?? [];
  const hasSizes = sizes.length > 0;
  const sizeLabel = store.niche === "retail" ? "المقاس" : "الحجم";

  const submit = () => {
    if (hasSizes && !size) {
      setNeedSize(true);
      return;
    }
    onAdd(product, { size: size ?? undefined, qty });
  };

  return (
    <div className="grid md:grid-cols-2">
      <div className="relative">
        <ProductImage
          product={product}
          className="aspect-[4/3] w-full md:h-full md:min-h-[440px] md:aspect-auto"
          emojiClassName="text-8xl"
        />
        <button
          type="button"
          onClick={onClose}
          aria-label="إغلاق"
          className="absolute end-3 top-3 grid h-10 w-10 place-items-center rounded-full bg-white/80 text-slate-700 shadow-soft backdrop-blur transition hover:bg-white"
        >
          <X size={18} />
        </button>
        {product.badge && (
          <span
            className="absolute start-3 top-3 rounded-full px-3 py-1 text-xs font-extrabold shadow-soft"
            style={{ background: "var(--brand)", color: "var(--brand-contrast)" }}
          >
            {product.badge}
          </span>
        )}
      </div>

      <div className="flex flex-col p-6 md:p-8">
        <p className="text-xs font-bold tracking-wide text-slate-400">
          {product.category}
        </p>
        <h2 className="mt-1 text-2xl font-extrabold leading-snug">{product.name}</h2>
        <p
          className="mt-2 text-2xl font-extrabold"
          style={{ color: "var(--brand)" }}
        >
          {formatPrice(product.price, store.currency)}
        </p>

        {product.description && (
          <p className="mt-4 text-sm leading-7 text-slate-600">
            {product.description}
          </p>
        )}

        {hasSizes && (
          <div className="mt-6">
            <p className="mb-2 text-sm font-bold text-slate-700">
              اختر {sizeLabel}
              {needSize && (
                <span className="ms-2 text-xs font-bold text-rose-500">
                  يرجى اختيار {sizeLabel} أولاً
                </span>
              )}
            </p>
            <div className="flex flex-wrap gap-2">
              {sizes.map((s) => {
                const active = size === s;
                return (
                  <button
                    key={s}
                    type="button"
                    onClick={() => {
                      setSize(s);
                      setNeedSize(false);
                    }}
                    className={cn(
                      "min-w-12 rounded-full border px-4 py-2 text-sm font-bold transition active:scale-95",
                      active
                        ? "border-transparent shadow-soft"
                        : "border-slate-200 bg-white text-slate-700 hover:border-slate-300",
                    )}
                    style={
                      active
                        ? { background: "var(--brand)", color: "var(--brand-contrast)" }
                        : undefined
                    }
                  >
                    {s}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        <div className="mt-auto pt-8">
          <div className="flex items-center gap-3">
            <div className="flex items-center rounded-full border border-slate-200 bg-white p-1">
              <button
                type="button"
                aria-label="إنقاص"
                onClick={() => setQty((q) => Math.max(1, q - 1))}
                className="grid h-10 w-10 place-items-center rounded-full text-slate-600 transition hover:bg-slate-100"
              >
                <Minus size={16} />
              </button>
              <span className="min-w-8 text-center font-extrabold">{qty}</span>
              <button
                type="button"
                aria-label="زيادة"
                onClick={() => setQty((q) => Math.min(99, q + 1))}
                className="grid h-10 w-10 place-items-center rounded-full text-slate-600 transition hover:bg-slate-100"
              >
                <Plus size={16} />
              </button>
            </div>

            <button
              type="button"
              onClick={submit}
              disabled={!product.available}
              className="btn btn-brand flex-1 py-3.5 text-base"
            >
              {product.available
                ? `أضف للسلة · ${formatPrice(product.price * qty, store.currency)}`
                : "غير متوفر حالياً"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
