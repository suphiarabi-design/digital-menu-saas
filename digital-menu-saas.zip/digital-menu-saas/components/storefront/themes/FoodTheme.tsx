"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Armchair, Clock, Minus, Plus } from "lucide-react";
import { useEffect, useMemo, useRef } from "react";
import ProductImage from "@/components/storefront/ProductImage";
import { groupByCategory } from "@/components/storefront/group";
import type { ThemeProps } from "@/components/storefront/types";
import { useScrollSpy } from "@/components/storefront/useScrollSpy";
import type { Product } from "@/lib/types";
import { cn, formatPrice } from "@/lib/utils";

/**
 * Food & Cafe theme: warm palette, scannable list cards, category chips that
 * follow scroll, and one-tap "instant cart" controls on every item.
 */
export default function FoodTheme({ store, cart, onOpenProduct, onQuickAdd }: ThemeProps) {
  const groups = useMemo(() => groupByCategory(store), [store]);
  const ids = useMemo(() => groups.map((_, i) => `cat-${i}`), [groups]);
  const active = useScrollSpy(ids);
  const chipRefs = useRef<Record<string, HTMLButtonElement | null>>({});

  useEffect(() => {
    if (!active) return;
    chipRefs.current[active]?.scrollIntoView({
      inline: "center",
      block: "nearest",
      behavior: "smooth",
    });
  }, [active]);

  const jumpTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <div>
      {/* Hero */}
      <header
        className="relative overflow-hidden px-5 pb-12 pt-10"
        style={{
          background: "linear-gradient(135deg, var(--brand), var(--brand-strong))",
          color: "var(--brand-contrast)",
        }}
      >
        <span className="absolute -end-10 -top-10 h-48 w-48 rounded-full bg-white/15 blur-2xl" />
        <span className="absolute -bottom-16 start-10 h-44 w-44 rounded-full bg-black/10 blur-2xl" />
        <div className="relative mx-auto max-w-2xl">
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="flex items-center gap-4"
          >
            <span className="grid h-16 w-16 place-items-center rounded-3xl bg-white/20 text-3xl backdrop-blur">
              ☕
            </span>
            <div>
              <h1 className="text-3xl font-extrabold leading-tight">{store.brandName}</h1>
              <p className="mt-1 text-sm opacity-90">{store.tagline}</p>
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.12 }}
            className="mt-6 flex flex-wrap gap-2 text-xs font-bold"
          >
            <span className="inline-flex items-center gap-1.5 rounded-full bg-white/20 px-3.5 py-2 backdrop-blur">
              <Clock size={14} /> مفتوح الآن
            </span>
            <span className="inline-flex items-center gap-1.5 rounded-full bg-white/20 px-3.5 py-2 backdrop-blur">
              <Armchair size={14} /> اطلب من طاولتك مباشرة
            </span>
          </motion.div>
        </div>
      </header>

      {/* Sticky category chips */}
      <nav className="sticky top-0 z-30 -mt-5 rounded-t-[28px] border-b border-black/5 bg-[#FFF9F2]/90 backdrop-blur-xl">
        <div className="no-scrollbar mx-auto flex max-w-2xl gap-2 overflow-x-auto px-4 py-3.5">
          {groups.map((g, i) => {
            const id = `cat-${i}`;
            const isActive = active === id;
            return (
              <button
                key={g.name}
                ref={(el) => {
                  chipRefs.current[id] = el;
                }}
                type="button"
                onClick={() => jumpTo(id)}
                className={cn(
                  "relative shrink-0 rounded-full px-4 py-2 text-sm font-bold transition",
                  isActive ? "" : "bg-white text-slate-600 ring-1 ring-black/5 hover:bg-white/80",
                )}
              >
                {isActive && (
                  <motion.span
                    layoutId="food-chip"
                    className="absolute inset-0 rounded-full"
                    style={{ background: "var(--brand)" }}
                    transition={{ type: "spring", stiffness: 420, damping: 34 }}
                  />
                )}
                <span
                  className="relative"
                  style={isActive ? { color: "var(--brand-contrast)" } : undefined}
                >
                  {g.name}
                </span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Menu */}
      <main className="mx-auto max-w-2xl space-y-9 px-4 pb-28 pt-6">
        {groups.map((g, i) => (
          <section key={g.name} id={`cat-${i}`} className="scroll-mt-20">
            <h2 className="mb-4 flex items-center gap-3 text-xl font-extrabold">
              {g.name}
              <span className="text-xs font-bold text-slate-400">{g.items.length}</span>
              <span className="h-px flex-1 bg-black/5" />
            </h2>
            <div className="space-y-4">
              {g.items.map((product) => (
                <FoodCard
                  key={product.id}
                  product={product}
                  currency={store.currency}
                  qty={cart.qtyOf(product.id)}
                  onOpen={() => onOpenProduct(product)}
                  onAdd={() => onQuickAdd(product)}
                  onDec={() => cart.decrement(product.id)}
                />
              ))}
            </div>
          </section>
        ))}

        {groups.length === 0 && (
          <div className="rounded-3xl bg-white p-10 text-center text-slate-500 shadow-soft">
            لا توجد منتجات في القائمة بعد.
          </div>
        )}
      </main>
    </div>
  );
}

interface FoodCardProps {
  product: Product;
  currency: string;
  qty: number;
  onOpen: () => void;
  onAdd: () => void;
  onDec: () => void;
}

function FoodCard({ product, currency, qty, onOpen, onAdd, onDec }: FoodCardProps) {
  const sold = !product.available;
  return (
    <motion.article
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.4 }}
      className={cn(
        "flex gap-4 rounded-[28px] bg-white p-3.5 shadow-soft ring-1 ring-black/5",
        sold && "opacity-60",
      )}
    >
      <button type="button" onClick={onOpen} className="min-w-0 flex-1 py-1 text-start">
        {product.badge && (
          <span
            className="mb-1.5 inline-block rounded-full px-2.5 py-0.5 text-[11px] font-extrabold"
            style={{ background: "var(--brand-soft)", color: "var(--brand-strong)" }}
          >
            {product.badge}
          </span>
        )}
        <h3 className="text-base font-extrabold leading-snug">{product.name}</h3>
        <p className="mt-1 line-clamp-2 text-sm leading-6 text-slate-500">
          {product.description}
        </p>
        <p className="mt-2 text-base font-extrabold" style={{ color: "var(--brand)" }}>
          {formatPrice(product.price, currency)}
        </p>
      </button>

      <div className="relative shrink-0 pb-3">
        <button type="button" onClick={onOpen} aria-label={product.name} className="block">
          <ProductImage
            product={product}
            className="h-28 w-28 rounded-3xl"
            emojiClassName="text-5xl"
          />
        </button>
        <div className="absolute -bottom-0 left-1/2 -translate-x-1/2">
          {sold ? (
            <span className="rounded-full bg-slate-800 px-3 py-1.5 text-xs font-bold text-white">
              نفد
            </span>
          ) : (
            <AddControl qty={qty} onAdd={onAdd} onDec={onDec} />
          )}
        </div>
      </div>
    </motion.article>
  );
}

function AddControl({
  qty,
  onAdd,
  onDec,
}: {
  qty: number;
  onAdd: () => void;
  onDec: () => void;
}) {
  return (
    <AnimatePresence mode="wait" initial={false}>
      {qty > 0 ? (
        <motion.div
          key="stepper"
          initial={{ scale: 0.85, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.85, opacity: 0 }}
          transition={{ duration: 0.15 }}
          className="flex items-center gap-0.5 rounded-full bg-white p-1 shadow-lift ring-1 ring-black/5"
        >
          <button
            type="button"
            onClick={onDec}
            aria-label="إنقاص"
            className="grid h-8 w-8 place-items-center rounded-full text-slate-600 transition hover:bg-slate-100"
          >
            <Minus size={16} />
          </button>
          <motion.span
            key={qty}
            initial={{ y: -6, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="min-w-6 text-center text-sm font-extrabold"
          >
            {qty}
          </motion.span>
          <button
            type="button"
            onClick={onAdd}
            aria-label="زيادة"
            className="btn-brand grid h-8 w-8 place-items-center rounded-full"
          >
            <Plus size={16} />
          </button>
        </motion.div>
      ) : (
        <motion.button
          key="add"
          type="button"
          onClick={onAdd}
          aria-label="أضف للسلة"
          initial={{ scale: 0.85, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.85, opacity: 0 }}
          whileTap={{ scale: 0.88 }}
          transition={{ duration: 0.15 }}
          className="btn-brand grid h-10 w-10 place-items-center rounded-full shadow-lift"
        >
          <Plus size={20} />
        </motion.button>
      )}
    </AnimatePresence>
  );
}
