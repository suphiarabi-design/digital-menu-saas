"use client";

import { motion } from "framer-motion";
import { Search, ShoppingBag, SlidersHorizontal, Truck } from "lucide-react";
import { useMemo, useState } from "react";
import ProductImage from "@/components/storefront/ProductImage";
import { groupByCategory } from "@/components/storefront/group";
import type { ThemeProps } from "@/components/storefront/types";
import { cn, formatPrice } from "@/lib/utils";

type Sort = "new" | "low" | "high";

/**
 * Retail & General Store theme: classic e-commerce grid with search,
 * category filters, price sorting and size chips on every card.
 */
export default function RetailTheme({
  store,
  cart,
  onOpenProduct,
  onQuickAdd,
  onOpenCart,
}: ThemeProps) {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");
  const [sort, setSort] = useState<Sort>("new");

  const tabs = useMemo(() => groupByCategory(store).map((g) => g.name), [store]);

  const items = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = store.products.filter((p) => {
      const inCategory =
        category === "all" ||
        p.category === category ||
        (category === "أخرى" && !store.categories.includes(p.category));
      const matches =
        !q || p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q);
      return inCategory && matches;
    });
    if (sort === "low") return [...list].sort((a, b) => a.price - b.price);
    if (sort === "high") return [...list].sort((a, b) => b.price - a.price);
    return list;
  }, [store, query, category, sort]);

  return (
    <div>
      {/* Promo strip */}
      <div
        className="flex items-center justify-center gap-2 px-4 py-2 text-center text-xs font-bold"
        style={{ background: "var(--brand)", color: "var(--brand-contrast)" }}
      >
        <Truck size={14} />
        اطلب الآن وأكمل الطلب بسهولة عبر واتساب
      </div>

      {/* Top bar */}
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3">
          <h1 className="shrink-0 text-lg font-extrabold">{store.brandName}</h1>

          <div className="relative mx-auto hidden max-w-md flex-1 sm:block">
            <Search
              size={16}
              className="pointer-events-none absolute start-4 top-1/2 -translate-y-1/2 text-slate-400"
            />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="ابحث عن منتج…"
              className="input !rounded-full !bg-slate-100 !py-2.5 !ps-11 !shadow-none"
            />
          </div>

          <button
            type="button"
            onClick={onOpenCart}
            aria-label="السلة"
            className="relative ms-auto grid h-11 w-11 shrink-0 place-items-center rounded-full bg-slate-100 transition hover:bg-slate-200 sm:ms-0"
          >
            <ShoppingBag size={20} />
            {cart.count > 0 && (
              <motion.span
                key={cart.count}
                initial={{ scale: 1.5 }}
                animate={{ scale: 1 }}
                className="absolute -end-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full px-1 text-[11px] font-extrabold"
                style={{ background: "var(--brand)", color: "var(--brand-contrast)" }}
              >
                {cart.count}
              </motion.span>
            )}
          </button>
        </div>

        {/* Mobile search */}
        <div className="px-4 pb-3 sm:hidden">
          <div className="relative">
            <Search
              size={16}
              className="pointer-events-none absolute start-4 top-1/2 -translate-y-1/2 text-slate-400"
            />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="ابحث عن منتج…"
              className="input !rounded-full !bg-slate-100 !py-2.5 !ps-11 !shadow-none"
            />
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 pb-28 pt-6">
        {/* Filters */}
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 md:mx-0 md:px-0">
            {["all", ...tabs].map((t) => {
              const isActive = category === t;
              return (
                <button
                  key={t}
                  type="button"
                  onClick={() => setCategory(t)}
                  className={cn(
                    "shrink-0 rounded-full border px-4 py-2 text-sm font-bold transition active:scale-95",
                    isActive
                      ? "border-transparent shadow-soft"
                      : "border-slate-200 bg-white text-slate-600 hover:border-slate-300",
                  )}
                  style={
                    isActive
                      ? { background: "var(--brand)", color: "var(--brand-contrast)" }
                      : undefined
                  }
                >
                  {t === "all" ? "الكل" : t}
                </button>
              );
            })}
          </div>

          <label className="flex shrink-0 items-center gap-2 text-sm text-slate-500">
            <SlidersHorizontal size={16} />
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value as Sort)}
              className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700 outline-none"
            >
              <option value="new">الأحدث</option>
              <option value="low">السعر: الأقل أولاً</option>
              <option value="high">السعر: الأعلى أولاً</option>
            </select>
          </label>
        </div>

        <p className="mb-4 mt-5 text-sm text-slate-500">{items.length} منتج</p>

        {/* Grid */}
        <motion.div
          key={`${category}-${sort}-${query}`}
          initial="hidden"
          animate="show"
          variants={{ show: { transition: { staggerChildren: 0.04 } } }}
          className="grid grid-cols-2 gap-3 md:grid-cols-3 md:gap-5 lg:grid-cols-4"
        >
          {items.map((product) => {
            const sold = !product.available;
            const sizes = product.sizes ?? [];
            return (
              <motion.article
                key={product.id}
                variants={{
                  hidden: { opacity: 0, y: 14 },
                  show: { opacity: 1, y: 0, transition: { duration: 0.35 } },
                }}
                className={cn(
                  "group flex flex-col overflow-hidden rounded-3xl border border-slate-200 bg-white transition hover:-translate-y-0.5 hover:shadow-lift",
                  sold && "opacity-60",
                )}
              >
                <button
                  type="button"
                  onClick={() => onOpenProduct(product)}
                  aria-label={product.name}
                  className="relative block overflow-hidden"
                >
                  <ProductImage
                    product={product}
                    className="aspect-square w-full transition duration-500 group-hover:scale-105"
                    emojiClassName="text-6xl"
                  />
                  {product.badge && (
                    <span
                      className="absolute start-3 top-3 rounded-full px-2.5 py-1 text-[11px] font-extrabold shadow-soft"
                      style={{ background: "var(--brand)", color: "var(--brand-contrast)" }}
                    >
                      {product.badge}
                    </span>
                  )}
                </button>

                <div className="flex flex-1 flex-col p-3.5">
                  <h3 className="line-clamp-1 text-sm font-extrabold">{product.name}</h3>
                  <p className="mt-0.5 line-clamp-1 text-xs text-slate-400">
                    {product.category}
                  </p>

                  {sizes.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1">
                      {sizes.slice(0, 4).map((s) => (
                        <span
                          key={s}
                          className="rounded-md border border-slate-200 px-1.5 py-0.5 text-[10px] font-bold text-slate-500"
                        >
                          {s}
                        </span>
                      ))}
                      {sizes.length > 4 && (
                        <span className="px-1 text-[10px] font-bold text-slate-400">
                          +{sizes.length - 4}
                        </span>
                      )}
                    </div>
                  )}

                  <div className="mt-auto flex items-center justify-between gap-2 pt-3">
                    <p className="text-sm font-extrabold">
                      {formatPrice(product.price, store.currency)}
                    </p>
                    <button
                      type="button"
                      disabled={sold}
                      onClick={() => onQuickAdd(product)}
                      className="btn btn-brand !px-3.5 !py-2 text-xs"
                    >
                      {sold ? "نفد" : sizes.length > 0 ? "اختر" : "أضف"}
                    </button>
                  </div>
                </div>
              </motion.article>
            );
          })}
        </motion.div>

        {items.length === 0 && (
          <div className="py-20 text-center">
            <p className="text-4xl">🔍</p>
            <p className="mt-3 font-bold text-slate-600">لا توجد نتائج مطابقة</p>
            <p className="mt-1 text-sm text-slate-400">جرّب كلمة بحث أخرى أو فئة مختلفة.</p>
          </div>
        )}
      </main>
    </div>
  );
}
