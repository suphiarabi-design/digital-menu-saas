"use client";

import { motion } from "framer-motion";
import { Plus, ShoppingBag } from "lucide-react";
import { useMemo, useState } from "react";
import ProductImage from "@/components/storefront/ProductImage";
import { groupByCategory } from "@/components/storefront/group";
import type { ThemeProps } from "@/components/storefront/types";
import { cn, formatPrice } from "@/lib/utils";

/**
 * Cosmetics & Beauty theme: airy minimalist grid, oversized 4:5 imagery,
 * understated typography, and a dedicated detail sheet for every product.
 */
export default function CosmeticsTheme({
  store,
  cart,
  onOpenProduct,
  onQuickAdd,
  onOpenCart,
}: ThemeProps) {
  const [category, setCategory] = useState<string>("all");

  const tabs = useMemo(() => groupByCategory(store).map((g) => g.name), [store]);
  const items = useMemo(
    () =>
      category === "all"
        ? store.products
        : store.products.filter((p) => p.category === category ||
            (category === "أخرى" && !store.categories.includes(p.category))),
    [store, category],
  );

  return (
    <div>
      {/* Top bar */}
      <header className="sticky top-0 z-30 border-b border-black/5 bg-white/70 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
          <span className="w-10" aria-hidden />
          <p className="text-lg font-light tracking-[0.2em]">{store.brandName}</p>
          <button
            type="button"
            onClick={onOpenCart}
            aria-label="السلة"
            className="relative grid h-10 w-10 place-items-center rounded-full transition hover:bg-black/5"
          >
            <ShoppingBag size={20} strokeWidth={1.6} />
            {cart.count > 0 && (
              <motion.span
                key={cart.count}
                initial={{ scale: 1.5 }}
                animate={{ scale: 1 }}
                className="absolute -end-0.5 -top-0.5 grid h-5 min-w-5 place-items-center rounded-full px-1 text-[11px] font-extrabold"
                style={{ background: "var(--brand)", color: "var(--brand-contrast)" }}
              >
                {cart.count}
              </motion.span>
            )}
          </button>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden px-5 py-16 text-center md:py-24">
        <span
          className="absolute left-1/2 top-0 h-72 w-72 -translate-x-1/2 rounded-full opacity-60 blur-3xl"
          style={{ background: "var(--brand-soft)" }}
        />
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="relative mx-auto max-w-xl"
        >
          <p className="text-xs font-bold tracking-[0.3em]" style={{ color: "var(--brand)" }}>
            COLLECTION
          </p>
          <h1 className="mt-4 text-4xl font-light leading-tight md:text-5xl">
            {store.tagline || store.brandName}
          </h1>
          <p className="mx-auto mt-4 max-w-sm text-sm leading-7 text-slate-500">
            اكتشفي مجموعتنا المختارة بعناية، وأرسلي طلبك مباشرة عبر واتساب.
          </p>
        </motion.div>
      </section>

      {/* Category tabs */}
      <nav className="no-scrollbar mx-auto flex max-w-6xl justify-start gap-7 overflow-x-auto px-5 md:justify-center">
        {["all", ...tabs].map((t) => {
          const isActive = category === t;
          return (
            <button
              key={t}
              type="button"
              onClick={() => setCategory(t)}
              className={cn(
                "relative shrink-0 pb-3 text-sm font-bold transition",
                isActive ? "text-slate-900" : "text-slate-400 hover:text-slate-600",
              )}
            >
              {t === "all" ? "الكل" : t}
              {isActive && (
                <motion.span
                  layoutId="cos-tab"
                  className="absolute inset-x-0 bottom-0 h-0.5 rounded-full"
                  style={{ background: "var(--brand)" }}
                  transition={{ type: "spring", stiffness: 420, damping: 34 }}
                />
              )}
            </button>
          );
        })}
      </nav>
      <div className="mx-auto h-px max-w-6xl bg-black/5" />

      {/* Grid */}
      <main className="mx-auto max-w-6xl px-5 pb-28 pt-10">
        <motion.div
          key={category}
          initial="hidden"
          animate="show"
          variants={{ show: { transition: { staggerChildren: 0.06 } } }}
          className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-3 lg:grid-cols-4"
        >
          {items.map((product) => (
            <motion.article
              key={product.id}
              variants={{
                hidden: { opacity: 0, y: 20 },
                show: { opacity: 1, y: 0, transition: { duration: 0.45 } },
              }}
              className={cn("group", !product.available && "opacity-60")}
            >
              <div className="relative">
                <button
                  type="button"
                  onClick={() => onOpenProduct(product)}
                  aria-label={product.name}
                  className="relative block w-full overflow-hidden rounded-[28px] bg-white shadow-soft"
                >
                  <ProductImage
                    product={product}
                    className="aspect-[4/5] w-full transition duration-700 group-hover:scale-105"
                    emojiClassName="text-7xl md:text-8xl"
                  />
                  {product.badge && (
                    <span className="absolute start-3 top-3 rounded-full bg-white/85 px-3 py-1 text-[11px] font-extrabold backdrop-blur">
                      {product.badge}
                    </span>
                  )}
                  {!product.available && (
                    <span className="absolute inset-0 grid place-items-center bg-white/60 text-sm font-extrabold backdrop-blur-[2px]">
                      نفدت الكمية
                    </span>
                  )}
                </button>
                {product.available && (
                  <motion.button
                    type="button"
                    whileTap={{ scale: 0.88 }}
                    onClick={() => onQuickAdd(product)}
                    aria-label="أضف للسلة"
                    className="btn-brand absolute bottom-3 end-3 grid h-11 w-11 place-items-center rounded-full shadow-lift md:opacity-0 md:transition md:group-hover:opacity-100"
                  >
                    <Plus size={20} />
                  </motion.button>
                )}
              </div>
              <div className="mt-4 px-1">
                <p className="text-[11px] font-bold tracking-widest text-slate-400">
                  {product.category}
                </p>
                <h3 className="mt-1 text-[15px] font-bold leading-snug">{product.name}</h3>
                <p className="mt-1 text-sm font-bold" style={{ color: "var(--brand)" }}>
                  {formatPrice(product.price, store.currency)}
                </p>
              </div>
            </motion.article>
          ))}
        </motion.div>

        {items.length === 0 && (
          <p className="py-20 text-center text-slate-400">لا توجد منتجات في هذه الفئة.</p>
        )}
      </main>
    </div>
  );
}
