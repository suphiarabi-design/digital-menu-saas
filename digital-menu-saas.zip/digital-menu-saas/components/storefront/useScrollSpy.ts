"use client";

import { useEffect, useState } from "react";

/** Returns the id of the section currently under the sticky navigation. */
export function useScrollSpy(ids: string[]): string | null {
  const joined = ids.join("|");
  const [active, setActive] = useState<string | null>(ids[0] ?? null);

  useEffect(() => {
    const list = joined ? joined.split("|") : [];
    if (list.length === 0) return;
    setActive((cur) => (cur && list.includes(cur) ? cur : list[0]));

    const elements = list
      .map((id) => document.getElementById(id))
      .filter((el): el is HTMLElement => el !== null);
    if (elements.length === 0) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);
        if (visible[0]) setActive(visible[0].target.id);
      },
      { rootMargin: "-25% 0px -65% 0px" },
    );
    elements.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, [joined]);

  return active;
}
