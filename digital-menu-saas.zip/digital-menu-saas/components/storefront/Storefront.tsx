"use client";

import { AnimatePresence, motion } from "framer-motion";
import Link from "next/link";
import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type ComponentType,
} from "react";
import { BRAND } from "@/lib/brand";
import { useCart } from "@/lib/cart";
import { useStorefrontData } from "@/lib/store";
import { NICHES } from "@/lib/themes";
import type { Niche, Product } from "@/lib/types";
import { brandVars, cn } from "@/lib/utils";
import CartDrawer from "./CartDrawer";
import FloatingCart from "./FloatingCart";
import ProductSheet from "./ProductSheet";
import CosmeticsTheme from "./themes/CosmeticsTheme";
import FoodTheme from "./themes/FoodTheme";
import RetailTheme from "./themes/RetailTheme";
import type { ThemeProps } from "./types";

/** The theme engine: one component per niche, chosen from the store settings. */
const THEMES: Record<Niche, ComponentType<ThemeProps>> = {
  food: FoodTheme,
  cosmetics: CosmeticsTheme,
  retail: RetailTheme,
};

export default function Storefront({ slug }: { slug: string }) {
  const { store, status } = useStorefrontData(slug);
  const cart = useCart(slug);
  const { add } = cart;

  const [cartOpen, setCartOpen] = useState(false);
  const [activeProduct, setActiveProduct] = useState<Product | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const notify = useCallback((message: string) => {
    setToast(message);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 1800);
  }, []);

  useEffect(
    () => () => {
      if (toastTimer.current) clearTimeout(toastTimer.current);
    },
    [],
  );

  useEffect(() => {
    if (store) document.title = store.brandName;
  }, [store]);

  const handleQuickAdd = useCallback(
    (product: Product) => {
      if (!product.available) return;
      // Products with options need a choice first: open the details sheet.
      if (product.sizes && product.sizes.length > 0) {
        setActiveProduct(product);
        return;
      }
      add(product);
      notify(`أُضيف «${product.name}» إلى السلة`);
      try {
        navigator.vibrate?.(8);
      } catch {
        /* vibration unsupported */
      }
    },
    [add, notify],
  );

  const handleSheetAdd = useCallback(
    (product: Product, opts: { size?: string; qty: number }) => {
      add(product, opts);
      setActiveProduct(null);
      notify(`أُضيف «${product.name}» إلى السلة`);
    },
    [add, notify],
  );

  const closeSheet = useCallback(() => setActiveProduct(null), []);
  const closeCart = useCallback(() => setCartOpen(false), []);

  if (status === "loading") return <StorefrontSkeleton />;
  if (!store) return <StoreNotFound slug={slug} />;

  const Theme = THEMES[store.niche] ?? THEMES.retail;
  const pageBg = NICHES[store.niche]?.page ?? "bg-slate-50";

  return (
    <div style={brandVars(store.primaryColor)} className={cn("min-h-dvh", pageBg)}>
      <Theme
        store={store}
        cart={cart}
        onOpenProduct={setActiveProduct}
        onQuickAdd={handleQuickAdd}
        onOpenCart={() => setCartOpen(true)}
      />

      <footer className="pb-6 text-center text-xs text-slate-400">
        مدعوم من{" "}
        <Link href="/" className="font-bold text-slate-500 hover:underline">
          {BRAND.name}
        </Link>
      </footer>

      <FloatingCart
        count={cart.count}
        total={cart.total}
        currency={store.currency}
        hidden={cartOpen}
        onOpen={() => setCartOpen(true)}
      />

      <CartDrawer open={cartOpen} onClose={closeCart} store={store} cart={cart} />

      <ProductSheet
        product={activeProduct}
        store={store}
        onClose={closeSheet}
        onAdd={handleSheetAdd}
      />

      <AnimatePresence>
        {toast && (
          <motion.div
            key={toast}
            initial={{ opacity: 0, y: -16, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -16 }}
            className="pointer-events-none fixed inset-x-0 top-4 z-[60] flex justify-center px-4"
          >
            <div className="rounded-full bg-slate-900/90 px-5 py-2.5 text-sm font-bold text-white shadow-lift backdrop-blur">
              {toast}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function StorefrontSkeleton() {
  return (
    <div className="min-h-dvh bg-slate-50" aria-busy="true" aria-label="جارٍ التحميل">
      <div className="skeleton h-44 w-full" />
      <div className="mx-auto max-w-2xl space-y-4 px-4 pt-6">
        <div className="skeleton h-10 w-2/3 rounded-full" />
        {[0, 1, 2].map((i) => (
          <div key={i} className="skeleton h-32 w-full rounded-[28px]" />
        ))}
      </div>
    </div>
  );
}

function StoreNotFound({ slug }: { slug: string }) {
  return (
    <main className="aurora grid min-h-dvh place-items-center px-6 text-center">
      <div className="glass-strong max-w-md rounded-[32px] p-10">
        <p className="text-6xl">🧭</p>
        <h1 className="mt-5 text-2xl font-extrabold">لم نعثر على هذا المتجر</h1>
        <p className="mt-3 text-sm leading-7 text-slate-500">
          لا يوجد متجر بالعنوان{" "}
          <span dir="ltr" className="font-bold text-slate-700">
            /{slug}
          </span>
          . تأكد من الرابط أو أنشئ متجرك الخاص الآن.
        </p>
        <div className="mt-7 flex flex-wrap justify-center gap-3">
          <Link href="/dashboard" className="btn btn-dark">
            أنشئ متجرك
          </Link>
          <Link href="/" className="btn btn-ghost">
            الصفحة الرئيسية
          </Link>
        </div>
      </div>
    </main>
  );
}
