"use client";

import { AnimatePresence, motion } from "framer-motion";
import {
  CheckCircle2,
  MessageCircle,
  Minus,
  Plus,
  ShoppingBag,
  Trash2,
  X,
} from "lucide-react";
import { useEffect, useState } from "react";
import type { CartApi } from "@/lib/cart";
import type { CheckoutDetails, OrderType, StoreSettings } from "@/lib/types";
import { cn, formatPrice } from "@/lib/utils";
import { buildOrderMessage, buildWhatsAppUrl, isValidPhone } from "@/lib/whatsapp";
import ProductImage from "./ProductImage";

interface CartDrawerProps {
  open: boolean;
  onClose: () => void;
  store: StoreSettings;
  cart: CartApi;
}

const FOOD_TYPES: { id: OrderType; label: string }[] = [
  { id: "dine-in", label: "داخل المحل" },
  { id: "takeaway", label: "سفري" },
];

const SHOP_TYPES: { id: OrderType; label: string }[] = [
  { id: "delivery", label: "توصيل" },
  { id: "pickup", label: "استلام من المتجر" },
];

function useIsDesktop(): boolean {
  const [value, setValue] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(min-width: 768px)");
    const update = () => setValue(mq.matches);
    update();
    mq.addEventListener("change", update);
    return () => mq.removeEventListener("change", update);
  }, []);
  return value;
}

/**
 * Cart + WhatsApp checkout. Bottom sheet on mobile, side panel on desktop.
 * The form adapts to the store niche (table number for food, address for shops).
 */
export default function CartDrawer({ open, onClose, store, cart }: CartDrawerProps) {
  const isDesktop = useIsDesktop();
  const isFood = store.niche === "food";
  const orderTypes = isFood ? FOOD_TYPES : SHOP_TYPES;

  const [details, setDetails] = useState<CheckoutDetails>({
    name: "",
    orderType: isFood ? "dine-in" : "delivery",
    tableNumber: "",
    address: "",
    notes: "",
  });
  const [error, setError] = useState("");
  const [sentUrl, setSentUrl] = useState<string | null>(null);

  // The niche can change live (dashboard preview), so keep the order type valid.
  const orderType: OrderType = orderTypes.some((t) => t.id === details.orderType)
    ? details.orderType
    : orderTypes[0].id;

  const patch = (p: Partial<CheckoutDetails>) => {
    setDetails((d) => ({ ...d, ...p }));
    setError("");
  };

  // Lock page scroll and close on Escape while open.
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);

  // Reset the success screen after the drawer finished closing.
  useEffect(() => {
    if (open) return;
    const t = setTimeout(() => setSentUrl(null), 400);
    return () => clearTimeout(t);
  }, [open]);

  const submit = () => {
    if (cart.lines.length === 0) return;
    if (!isValidPhone(store.whatsapp)) {
      setError("رقم واتساب المتجر غير مضبوط حالياً. يرجى التواصل مع المتجر مباشرة.");
      return;
    }
    if (isFood) {
      if (orderType === "dine-in" && !details.tableNumber.trim()) {
        setError("يرجى إدخال رقم الطاولة.");
        return;
      }
    } else {
      if (!details.name.trim()) {
        setError("يرجى إدخال اسمك.");
        return;
      }
      if (orderType === "delivery" && !details.address.trim()) {
        setError("يرجى إدخال عنوان التوصيل.");
        return;
      }
    }

    const message = buildOrderMessage({
      store,
      lines: cart.lines,
      details: { ...details, orderType },
    });
    const url = buildWhatsAppUrl(store.whatsapp, message);
    window.open(url, "_blank", "noopener,noreferrer");
    setSentUrl(url);
    cart.clear();
    setDetails((d) => ({ ...d, notes: "" }));
  };

  const slide = isDesktop ? { x: "-100%" } : { y: "100%" };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-50"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <div
            className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            onClick={onClose}
            aria-hidden
          />

          <motion.aside
            role="dialog"
            aria-modal="true"
            aria-label="سلة المشتريات"
            className="absolute inset-x-0 bottom-0 flex max-h-[92dvh] flex-col rounded-t-[32px] bg-white shadow-lift md:bottom-0 md:left-0 md:right-auto md:top-0 md:max-h-none md:w-[440px] md:rounded-none md:rounded-r-[32px]"
            initial={slide}
            animate={{ x: 0, y: 0 }}
            exit={slide}
            transition={{ type: "spring", damping: 32, stiffness: 320 }}
          >
            {/* Header */}
            <header className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
              <div className="flex items-center gap-3">
                <span
                  className="grid h-10 w-10 place-items-center rounded-2xl"
                  style={{ background: "var(--brand-soft)", color: "var(--brand)" }}
                >
                  <ShoppingBag size={20} />
                </span>
                <div>
                  <h2 className="text-lg font-extrabold leading-tight">سلتك</h2>
                  <p className="text-xs text-slate-500">
                    {cart.count > 0 ? `${cart.count} منتجات` : store.brandName}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                aria-label="إغلاق"
                className="rounded-full p-2 text-slate-500 transition hover:bg-slate-100"
              >
                <X size={20} />
              </button>
            </header>

            {/* Body */}
            <div className="flex-1 overflow-y-auto px-5 py-4">
              {sentUrl ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.96 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex h-full min-h-[320px] flex-col items-center justify-center text-center"
                >
                  <motion.span
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", stiffness: 260, damping: 14, delay: 0.1 }}
                    className="grid h-20 w-20 place-items-center rounded-full bg-emerald-50 text-emerald-500"
                  >
                    <CheckCircle2 size={44} />
                  </motion.span>
                  <h3 className="mt-5 text-xl font-extrabold">تم تجهيز طلبك</h3>
                  <p className="mt-2 max-w-xs text-sm leading-7 text-slate-500">
                    فتحنا لك واتساب برسالة جاهزة. اضغط «إرسال» هناك لإتمام الطلب.
                  </p>
                  <a
                    href={sentUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn btn-ghost mt-6"
                  >
                    <MessageCircle size={16} />
                    فتح واتساب مرة أخرى
                  </a>
                  <button type="button" onClick={onClose} className="btn btn-brand mt-3 px-8">
                    متابعة التصفح
                  </button>
                </motion.div>
              ) : cart.lines.length === 0 ? (
                <div className="flex h-full min-h-[280px] flex-col items-center justify-center text-center">
                  <span className="text-5xl">🛒</span>
                  <h3 className="mt-4 text-lg font-extrabold">السلة فارغة</h3>
                  <p className="mt-1 text-sm text-slate-500">أضف بعض المنتجات لتبدأ طلبك.</p>
                </div>
              ) : (
                <>
                  <ul className="space-y-3">
                    <AnimatePresence initial={false}>
                      {cart.lines.map((line) => {
                        const product = store.products.find((p) => p.id === line.productId);
                        return (
                          <motion.li
                            key={line.key}
                            layout
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: "auto" }}
                            exit={{ opacity: 0, height: 0 }}
                            transition={{ duration: 0.22 }}
                            className="overflow-hidden"
                          >
                            <div className="flex items-center gap-3 rounded-3xl border border-slate-100 bg-slate-50/60 p-2.5">
                              <ProductImage
                                product={
                                  product ?? { name: line.name, emoji: "🛍️", hue: 220 }
                                }
                                className="h-16 w-16 shrink-0 rounded-2xl"
                                emojiClassName="text-2xl"
                              />
                              <div className="min-w-0 flex-1">
                                <p className="truncate text-sm font-extrabold">{line.name}</p>
                                {line.size && (
                                  <p className="text-xs text-slate-500">{line.size}</p>
                                )}
                                <p
                                  className="mt-0.5 text-sm font-bold"
                                  style={{ color: "var(--brand)" }}
                                >
                                  {formatPrice(line.price * line.qty, store.currency)}
                                </p>
                              </div>
                              <div className="flex flex-col items-end gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => cart.remove(line.key)}
                                  aria-label="حذف"
                                  className="rounded-full p-1.5 text-slate-400 transition hover:bg-rose-50 hover:text-rose-500"
                                >
                                  <Trash2 size={15} />
                                </button>
                                <div className="flex items-center rounded-full bg-white p-0.5 shadow-sm ring-1 ring-black/5">
                                  <button
                                    type="button"
                                    aria-label="إنقاص"
                                    onClick={() => cart.setQty(line.key, line.qty - 1)}
                                    className="grid h-7 w-7 place-items-center rounded-full text-slate-600 hover:bg-slate-100"
                                  >
                                    <Minus size={13} />
                                  </button>
                                  <span className="min-w-6 text-center text-sm font-extrabold">
                                    {line.qty}
                                  </span>
                                  <button
                                    type="button"
                                    aria-label="زيادة"
                                    onClick={() => cart.setQty(line.key, line.qty + 1)}
                                    className="grid h-7 w-7 place-items-center rounded-full text-slate-600 hover:bg-slate-100"
                                  >
                                    <Plus size={13} />
                                  </button>
                                </div>
                              </div>
                            </div>
                          </motion.li>
                        );
                      })}
                    </AnimatePresence>
                  </ul>

                  {/* Checkout details */}
                  <div className="mt-6 space-y-4">
                    <h3 className="text-sm font-extrabold text-slate-800">بيانات الطلب</h3>

                    <div className="grid grid-cols-2 gap-2 rounded-2xl bg-slate-100 p-1">
                      {orderTypes.map((t) => (
                        <button
                          key={t.id}
                          type="button"
                          onClick={() => patch({ orderType: t.id })}
                          className={cn(
                            "rounded-xl py-2.5 text-sm font-bold transition",
                            orderType === t.id
                              ? "bg-white text-slate-900 shadow-sm"
                              : "text-slate-500 hover:text-slate-700",
                          )}
                        >
                          {t.label}
                        </button>
                      ))}
                    </div>

                    {isFood && orderType === "dine-in" && (
                      <div>
                        <label className="label" htmlFor="table-number">
                          رقم الطاولة
                        </label>
                        <input
                          id="table-number"
                          className="input"
                          inputMode="numeric"
                          placeholder="مثال: 7"
                          value={details.tableNumber}
                          onChange={(e) => patch({ tableNumber: e.target.value })}
                        />
                      </div>
                    )}

                    <div>
                      <label className="label" htmlFor="customer-name">
                        الاسم {isFood && <span className="font-normal text-slate-400">(اختياري)</span>}
                      </label>
                      <input
                        id="customer-name"
                        className="input"
                        placeholder="اسمك"
                        value={details.name}
                        onChange={(e) => patch({ name: e.target.value })}
                      />
                    </div>

                    {!isFood && orderType === "delivery" && (
                      <div>
                        <label className="label" htmlFor="address">
                          عنوان التوصيل
                        </label>
                        <input
                          id="address"
                          className="input"
                          placeholder="المدينة، الحي، الشارع"
                          value={details.address}
                          onChange={(e) => patch({ address: e.target.value })}
                        />
                      </div>
                    )}

                    <div>
                      <label className="label" htmlFor="notes">
                        ملاحظات <span className="font-normal text-slate-400">(اختياري)</span>
                      </label>
                      <textarea
                        id="notes"
                        rows={2}
                        className="input resize-none"
                        placeholder={isFood ? "بدون سكر، زيادة ثلج…" : "أي تفاصيل إضافية للطلب"}
                        value={details.notes}
                        onChange={(e) => patch({ notes: e.target.value })}
                      />
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Footer */}
            {!sentUrl && cart.lines.length > 0 && (
              <footer className="border-t border-slate-100 bg-white px-5 pb-safe pt-4">
                <AnimatePresence>
                  {error && (
                    <motion.p
                      initial={{ opacity: 0, y: -4 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      role="alert"
                      className="mb-3 rounded-2xl bg-rose-50 px-4 py-2.5 text-sm font-bold text-rose-600"
                    >
                      {error}
                    </motion.p>
                  )}
                </AnimatePresence>

                <div className="mb-3 flex items-center justify-between">
                  <span className="text-sm text-slate-500">الإجمالي</span>
                  <motion.span
                    key={cart.total}
                    initial={{ scale: 1.08 }}
                    animate={{ scale: 1 }}
                    className="text-xl font-extrabold"
                  >
                    {formatPrice(cart.total, store.currency)}
                  </motion.span>
                </div>

                <button
                  type="button"
                  onClick={submit}
                  className="btn w-full bg-[#25D366] py-4 text-base text-white shadow-lift hover:bg-[#1fb957]"
                >
                  <MessageCircle size={20} />
                  إرسال الطلب عبر واتساب
                </button>
                <p className="mt-2 text-center text-[11px] text-slate-400">
                  سيُفتح واتساب برسالة جاهزة بتفاصيل طلبك
                </p>
              </footer>
            )}
          </motion.aside>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
