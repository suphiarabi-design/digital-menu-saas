import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface CardProps {
  title?: string;
  description?: string;
  icon?: ReactNode;
  children: ReactNode;
  className?: string;
}

export default function Card({ title, description, icon, children, className }: CardProps) {
  return (
    <section
      className={cn(
        "rounded-[28px] border border-white bg-white/80 p-6 shadow-soft backdrop-blur sm:p-7",
        className,
      )}
    >
      {title && (
        <header className="mb-5 flex items-start gap-3">
          {icon && (
            <span
              className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl"
              style={{ background: "var(--brand-soft)", color: "var(--brand)" }}
            >
              {icon}
            </span>
          )}
          <div>
            <h2 className="text-lg font-extrabold">{title}</h2>
            {description && <p className="mt-0.5 text-sm text-slate-500">{description}</p>}
          </div>
        </header>
      )}
      {children}
    </section>
  );
}
