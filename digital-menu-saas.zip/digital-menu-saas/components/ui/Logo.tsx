import { Store } from "lucide-react";
import Link from "next/link";
import { BRAND } from "@/lib/brand";
import { cn } from "@/lib/utils";

export default function Logo({ className }: { className?: string }) {
  return (
    <Link
      href="/"
      className={cn("inline-flex items-center gap-2 font-extrabold tracking-tight", className)}
    >
      <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-violet-600 to-fuchsia-500 text-white shadow-soft">
        <Store size={18} />
      </span>
      <span className="text-xl">{BRAND.name}</span>
    </Link>
  );
}
