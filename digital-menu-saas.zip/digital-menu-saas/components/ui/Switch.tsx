"use client";

import { cn } from "@/lib/utils";

interface SwitchProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
  label: string;
}

/** Accessible toggle. The knob slides towards the end side in RTL layouts. */
export default function Switch({ checked, onChange, label }: SwitchProps) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={cn(
        "relative h-6 w-11 shrink-0 rounded-full transition-colors duration-200",
        checked ? "" : "bg-slate-300",
      )}
      style={checked ? { background: "var(--brand)" } : undefined}
    >
      <span
        className={cn(
          "absolute right-0.5 top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform duration-200",
          checked ? "-translate-x-5" : "translate-x-0",
        )}
      />
    </button>
  );
}
