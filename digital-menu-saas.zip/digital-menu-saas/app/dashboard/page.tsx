import type { Metadata } from "next";
import Dashboard from "@/components/dashboard/Dashboard";

export const metadata: Metadata = {
  title: "لوحة التحكم",
  robots: { index: false },
};

export default function DashboardPage() {
  return <Dashboard />;
}
