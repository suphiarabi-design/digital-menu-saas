import Features from "@/components/landing/Features";
import Footer from "@/components/landing/Footer";
import Hero from "@/components/landing/Hero";
import HowItWorks from "@/components/landing/HowItWorks";
import Navbar from "@/components/landing/Navbar";
import Niches from "@/components/landing/Niches";
import Pricing from "@/components/landing/Pricing";

export default function LandingPage() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <Features />
        <Niches />
        <HowItWorks />
        <Pricing />
      </main>
      <Footer />
    </>
  );
}
