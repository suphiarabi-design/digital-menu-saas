import type { Metadata } from "next";
import Storefront from "@/components/storefront/Storefront";
import { getDemoStore } from "@/lib/seed";

interface PageProps {
  params: Promise<{ brand: string }>;
}

function decodeSlug(raw: string): string {
  try {
    return decodeURIComponent(raw).toLowerCase();
  } catch {
    return raw.toLowerCase();
  }
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { brand } = await params;
  const demo = getDemoStore(decodeSlug(brand));
  return {
    title: demo ? demo.brandName : "المتجر",
    description: demo?.tagline,
  };
}

/**
 * Public storefront. The theme (food / cosmetics / retail) is chosen at
 * runtime inside <Storefront /> from the merchant's saved settings.
 */
export default async function BrandPage({ params }: PageProps) {
  const { brand } = await params;
  return <Storefront slug={decodeSlug(brand)} />;
}
