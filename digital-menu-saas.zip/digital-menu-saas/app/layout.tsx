import type { Metadata, Viewport } from "next";
import { Tajawal } from "next/font/google";
import type { ReactNode } from "react";
import "./globals.css";

const tajawal = Tajawal({
  subsets: ["arabic", "latin"],
  weight: ["300", "400", "500", "700", "800"],
  variable: "--font-tajawal",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "سوقي — متجرك ومنيوك الرقمي في دقائق",
    template: "%s | سوقي",
  },
  description:
    "منصة سحابية لإنشاء المتاجر والمنيو الرقمي للمطاعم والكافيهات ومتاجر التجميل والمتاجر العامة، مع استقبال الطلبات عبر واتساب.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#ffffff",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl" className={tajawal.variable}>
      <body className="bg-[#fafafa] font-sans text-slate-900 antialiased">
        {children}
      </body>
    </html>
  );
}
