import type { Niche } from "./types";

export interface NicheConfig {
  id: Niche;
  label: string;
  title: string;
  description: string;
  emoji: string;
  defaultColor: string;
  swatches: string[];
  highlights: string[];
  demoSlug: string;
  /** Tailwind classes for the storefront page background. */
  page: string;
}

export const NICHES: Record<Niche, NicheConfig> = {
  food: {
    id: "food",
    label: "مطاعم وكافيهات",
    title: "ثيم الطعام والقهوة",
    description:
      "ألوان دافئة، قائمة طعام سريعة التصفح، حقل رقم الطاولة، وسلة فورية بلمسة واحدة.",
    emoji: "☕",
    defaultColor: "#D9480F",
    swatches: ["#D9480F", "#B7791F", "#C2410C", "#9A3412", "#15803D", "#7C2D12"],
    highlights: ["رقم الطاولة", "سلة فورية", "قائمة بالفئات"],
    demoSlug: "cafe-demo",
    page: "bg-[#FFF9F2]",
  },
  cosmetics: {
    id: "cosmetics",
    label: "تجميل وعناية",
    title: "ثيم التجميل والعناية",
    description:
      "شبكة نظيفة وبسيطة، تركيز كامل على الصور عالية الدقة، وصفحة تفاصيل أنيقة لكل منتج.",
    emoji: "💄",
    defaultColor: "#C2557D",
    swatches: ["#C2557D", "#A855F7", "#BE185D", "#9D174D", "#0F766E", "#57534E"],
    highlights: ["تركيز على الصور", "تفاصيل المنتج", "تصميم هادئ"],
    demoSlug: "glow-demo",
    page: "bg-[#FDFBFA]",
  },
  retail: {
    id: "retail",
    label: "تجزئة ومتاجر عامة",
    title: "ثيم المتجر العام",
    description:
      "شبكة تجارة إلكترونية قياسية مع المقاسات والخيارات والبحث والترتيب والفلترة بالفئات.",
    emoji: "🛍️",
    defaultColor: "#2563EB",
    swatches: ["#2563EB", "#0EA5E9", "#7C3AED", "#111827", "#059669", "#DC2626"],
    highlights: ["مقاسات وخيارات", "بحث وفلترة", "ترتيب بالسعر"],
    demoSlug: "urban-demo",
    page: "bg-slate-50",
  },
};

export const NICHE_LIST: NicheConfig[] = [
  NICHES.food,
  NICHES.cosmetics,
  NICHES.retail,
];

export const CURRENCIES: { symbol: string; label: string }[] = [
  { symbol: "ر.س", label: "ريال سعودي (ر.س)" },
  { symbol: "د.إ", label: "درهم إماراتي (د.إ)" },
  { symbol: "د.ك", label: "دينار كويتي (د.ك)" },
  { symbol: "ر.ق", label: "ريال قطري (ر.ق)" },
  { symbol: "د.ب", label: "دينار بحريني (د.ب)" },
  { symbol: "ر.ع", label: "ريال عماني (ر.ع)" },
  { symbol: "ج.م", label: "جنيه مصري (ج.م)" },
  { symbol: "د.أ", label: "دينار أردني (د.أ)" },
  { symbol: "$", label: "دولار أمريكي ($)" },
];

export const PRODUCT_EMOJIS: string[] = [
  "☕", "🧊", "🍰", "🥐", "🍫", "🥪", "🥗", "🍓",
  "🍊", "🧴", "💄", "🌸", "✨", "💧", "🌿", "👕",
  "👖", "🧥", "👟", "🎒", "⌚", "🕶️", "🛍️", "🎁",
];
