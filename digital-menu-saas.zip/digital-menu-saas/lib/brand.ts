/** Platform-level branding. Rename the product here in one place. */
export const BRAND = {
  name: "سوقي",
  tagline: "منصة المتاجر والمنيو الرقمي",
  domain: "souqi.app",
} as const;

/** Slugs that can never be used as a public store address. */
export const RESERVED_SLUGS: readonly string[] = [
  "dashboard",
  "api",
  "admin",
  "login",
  "signup",
  "pricing",
  "static",
  "assets",
  "favicon",
];
