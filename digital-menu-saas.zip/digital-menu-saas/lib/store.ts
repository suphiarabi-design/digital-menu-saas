"use client";

/**
 * Persistence layer.
 *
 * This demo keeps the merchant's store in localStorage so the whole product
 * works without a backend. Everything that touches storage lives in this file
 * (plus lib/cart.ts), so swapping it for a real database means replacing
 * `readStore` / `writeStore` with API calls (e.g. Supabase, Prisma + Postgres).
 */

import { useCallback, useEffect, useRef, useState } from "react";
import { getDemoStore } from "./seed";
import type { StoreSettings } from "./types";

export const STORE_KEY = "souqi:store:v1";

export function readStore(): StoreSettings | null {
  try {
    const raw = window.localStorage.getItem(STORE_KEY);
    return raw ? (JSON.parse(raw) as StoreSettings) : null;
  } catch {
    return null;
  }
}

export function writeStore(store: StoreSettings | null): void {
  try {
    if (store) window.localStorage.setItem(STORE_KEY, JSON.stringify(store));
    else window.localStorage.removeItem(STORE_KEY);
  } catch {
    /* storage full or unavailable: ignore */
  }
}

/* ------------------------------------------------------------------ */
/* Dashboard hook                                                      */
/* ------------------------------------------------------------------ */

export function useMerchantStore() {
  const [store, setStore] = useState<StoreSettings | null>(null);
  const [ready, setReady] = useState(false);
  const latest = useRef<StoreSettings | null>(null);

  useEffect(() => {
    const initial = readStore();
    latest.current = initial;
    setStore(initial);
    setReady(true);

    const onStorage = (e: StorageEvent) => {
      if (e.key !== STORE_KEY) return;
      const next = readStore();
      latest.current = next;
      setStore(next);
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  const commit = useCallback((next: StoreSettings | null) => {
    latest.current = next;
    writeStore(next);
    setStore(next);
  }, []);

  /** Create or fully replace the store. */
  const save = useCallback(
    (next: StoreSettings) => commit({ ...next, updatedAt: Date.now() }),
    [commit],
  );

  /** Merge a partial update into the current store. */
  const update = useCallback(
    (patch: Partial<StoreSettings>) => {
      const current = latest.current;
      if (!current) return;
      commit({ ...current, ...patch, updatedAt: Date.now() });
    },
    [commit],
  );

  const reset = useCallback(() => commit(null), [commit]);

  return { store, ready, save, update, reset };
}

/* ------------------------------------------------------------------ */
/* Storefront hook                                                     */
/* ------------------------------------------------------------------ */

export type StorefrontStatus = "loading" | "ready" | "missing";

/**
 * Resolves the store behind /{slug}: the merchant's own store when the slug
 * matches, otherwise one of the built-in demo stores.
 */
export function useStorefrontData(slug: string) {
  const [store, setStore] = useState<StoreSettings | null>(null);
  const [status, setStatus] = useState<StorefrontStatus>("loading");

  useEffect(() => {
    const resolve = () => {
      const mine = readStore();
      const found = mine && mine.slug === slug ? mine : getDemoStore(slug);
      setStore(found);
      setStatus(found ? "ready" : "missing");
    };
    resolve();

    const onStorage = (e: StorageEvent) => {
      if (e.key === STORE_KEY) resolve();
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, [slug]);

  return { store, status };
}
