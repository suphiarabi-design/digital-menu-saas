"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import type { CartLine, Product } from "./types";

const cartKey = (slug: string) => `souqi:cart:${slug}`;

export function useCart(slug: string) {
  const [lines, setLines] = useState<CartLine[]>([]);
  const [loadedKey, setLoadedKey] = useState<string | null>(null);
  const key = cartKey(slug);

  // Load the persisted cart for this storefront.
  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(key);
      setLines(raw ? (JSON.parse(raw) as CartLine[]) : []);
    } catch {
      setLines([]);
    }
    setLoadedKey(key);
  }, [key]);

  // Persist on every change, but only after the initial load for this key.
  useEffect(() => {
    if (loadedKey !== key) return;
    try {
      window.localStorage.setItem(key, JSON.stringify(lines));
    } catch {
      /* ignore */
    }
  }, [lines, loadedKey, key]);

  const add = useCallback(
    (product: Product, opts: { size?: string; qty?: number } = {}) => {
      const qty = Math.max(1, opts.qty ?? 1);
      const lineKey = `${product.id}|${opts.size ?? ""}`;
      setLines((prev) => {
        const existing = prev.find((l) => l.key === lineKey);
        if (existing) {
          return prev.map((l) =>
            l.key === lineKey ? { ...l, qty: l.qty + qty } : l,
          );
        }
        return [
          ...prev,
          {
            key: lineKey,
            productId: product.id,
            name: product.name,
            price: product.price,
            qty,
            size: opts.size,
          },
        ];
      });
    },
    [],
  );

  const setQty = useCallback((lineKey: string, qty: number) => {
    setLines((prev) =>
      qty <= 0
        ? prev.filter((l) => l.key !== lineKey)
        : prev.map((l) => (l.key === lineKey ? { ...l, qty } : l)),
    );
  }, []);

  const remove = useCallback((lineKey: string) => {
    setLines((prev) => prev.filter((l) => l.key !== lineKey));
  }, []);

  const clear = useCallback(() => setLines([]), []);

  /** Total quantity of a product across all of its sizes. */
  const qtyOf = useCallback(
    (productId: string) =>
      lines.filter((l) => l.productId === productId).reduce((s, l) => s + l.qty, 0),
    [lines],
  );

  /** Decrease the most recently added line of a product (used by card steppers). */
  const decrement = useCallback((productId: string) => {
    setLines((prev) => {
      const idx = [...prev].reverse().findIndex((l) => l.productId === productId);
      if (idx === -1) return prev;
      const realIdx = prev.length - 1 - idx;
      const line = prev[realIdx];
      if (line.qty <= 1) return prev.filter((_, i) => i !== realIdx);
      return prev.map((l, i) => (i === realIdx ? { ...l, qty: l.qty - 1 } : l));
    });
  }, []);

  const count = useMemo(() => lines.reduce((s, l) => s + l.qty, 0), [lines]);
  const total = useMemo(
    () => lines.reduce((s, l) => s + l.qty * l.price, 0),
    [lines],
  );

  return { lines, count, total, add, setQty, remove, clear, qtyOf, decrement };
}

export type CartApi = ReturnType<typeof useCart>;
