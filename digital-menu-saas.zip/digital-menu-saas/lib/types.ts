export type Niche = "food" | "cosmetics" | "retail";

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  /** Emoji shown on the generated placeholder image. */
  emoji: string;
  /** 0–360 hue used for the generated placeholder gradient. */
  hue: number;
  /** Optional real image URL. Falls back to the placeholder if missing or broken. */
  imageUrl?: string;
  /** Optional selectable options (clothing sizes, cup sizes, bottle volumes…). */
  sizes?: string[];
  /** Small ribbon text such as "الأكثر طلباً". */
  badge?: string;
  available: boolean;
}

export interface StoreSettings {
  /** URL segment of the public storefront: /{slug} */
  slug: string;
  brandName: string;
  tagline: string;
  /** Raw WhatsApp number as typed by the merchant. Normalised when used. */
  whatsapp: string;
  primaryColor: string;
  niche: Niche;
  /** Currency symbol shown next to prices. */
  currency: string;
  categories: string[];
  products: Product[];
  updatedAt: number;
}

export interface CartLine {
  key: string;
  productId: string;
  name: string;
  price: number;
  qty: number;
  size?: string;
}

export type OrderType = "dine-in" | "takeaway" | "delivery" | "pickup";

export interface CheckoutDetails {
  name: string;
  orderType: OrderType;
  tableNumber: string;
  address: string;
  notes: string;
}
