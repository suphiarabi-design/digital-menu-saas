import type { CartLine, CheckoutDetails, OrderType, StoreSettings } from "./types";
import { formatPrice, toLatinDigits } from "./utils";

export const ORDER_TYPE_LABEL: Record<OrderType, string> = {
  "dine-in": "داخل المحل",
  takeaway: "سفري",
  delivery: "توصيل",
  pickup: "استلام من المتجر",
};

/**
 * Normalises a phone number to the international digits-only format wa.me
 * expects (no "+", no spaces, no leading zeros).
 *  - "+966 50 123 4567" → "966501234567"
 *  - "00966501234567"   → "966501234567"
 *  - "0501234567"       → "966501234567"  (Saudi local format convenience)
 */
export function normalizePhone(input: string): string {
  let digits = toLatinDigits(input).replace(/\D/g, "");
  if (digits.startsWith("00")) digits = digits.slice(2);
  if (digits.length === 10 && digits.startsWith("05")) {
    digits = `966${digits.slice(1)}`;
  }
  return digits;
}

export function isValidPhone(input: string): boolean {
  const digits = normalizePhone(input);
  return digits.length >= 8 && digits.length <= 15;
}

export interface OrderContext {
  store: Pick<StoreSettings, "brandName" | "currency">;
  lines: CartLine[];
  details: CheckoutDetails;
}

const DIVIDER = "────────────────";

export function buildOrderMessage({ store, lines, details }: OrderContext): string {
  const total = lines.reduce((s, l) => s + l.qty * l.price, 0);
  const orderId = Date.now().toString(36).slice(-5).toUpperCase();
  const out: string[] = [];

  out.push(`🧾 *طلب جديد من ${store.brandName}*`);
  out.push(`رقم الطلب: #${orderId}`);
  out.push(DIVIDER);

  if (details.name.trim()) out.push(`👤 *الاسم:* ${details.name.trim()}`);
  out.push(`🛎️ *نوع الطلب:* ${ORDER_TYPE_LABEL[details.orderType]}`);
  if (details.orderType === "dine-in" && details.tableNumber.trim()) {
    out.push(`🪑 *رقم الطاولة:* ${details.tableNumber.trim()}`);
  }
  if (details.orderType === "delivery" && details.address.trim()) {
    out.push(`📍 *العنوان:* ${details.address.trim()}`);
  }

  out.push(DIVIDER);
  out.push("*تفاصيل الطلب*");
  lines.forEach((l, i) => {
    const size = l.size ? ` (${l.size})` : "";
    out.push(
      `${i + 1}. ${l.name}${size} × ${l.qty} = ${formatPrice(l.qty * l.price, store.currency)}`,
    );
  });

  out.push(DIVIDER);
  out.push(`💰 *الإجمالي:* ${formatPrice(total, store.currency)}`);
  if (details.notes.trim()) {
    out.push(`📝 *ملاحظات:* ${details.notes.trim()}`);
  }

  return out.join("\n");
}

export function buildWhatsAppUrl(phone: string, message: string): string {
  return `https://wa.me/${normalizePhone(phone)}?text=${encodeURIComponent(message)}`;
}
