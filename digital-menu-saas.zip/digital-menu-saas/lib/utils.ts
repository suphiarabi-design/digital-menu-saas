import type { CSSProperties } from "react";

export function cn(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(" ");
}

export function formatPrice(value: number, currency: string): string {
  const n = new Intl.NumberFormat("en-US", { maximumFractionDigits: 2 }).format(
    value,
  );
  return `${n} ${currency}`;
}

export function uid(prefix = "id"): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 8)}${Date.now()
    .toString(36)
    .slice(-3)}`;
}

/** 3–40 chars, lowercase latin letters, digits and hyphens, no edge hyphens. */
export const SLUG_RE = /^[a-z0-9][a-z0-9-]{1,38}[a-z0-9]$/;

export function slugify(input: string): string {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 40);
}

/** Converts Arabic-Indic and Persian digits to latin digits. */
export function toLatinDigits(input: string): string {
  return input
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 0x0660))
    .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 0x06f0));
}

/* ------------------------------------------------------------------ */
/* Colour helpers (used by the dynamic brand-colour theme engine)      */
/* ------------------------------------------------------------------ */

export function isValidHex(value: string): boolean {
  return /^#([0-9a-fA-F]{6}|[0-9a-fA-F]{3})$/.test(value.trim());
}

export function hexToRgb(hex: string): [number, number, number] {
  let h = hex.replace("#", "").trim();
  if (h.length === 3) {
    h = h
      .split("")
      .map((c) => c + c)
      .join("");
  }
  if (!/^[0-9a-fA-F]{6}$/.test(h)) return [109, 94, 252];
  return [
    parseInt(h.slice(0, 2), 16),
    parseInt(h.slice(2, 4), 16),
    parseInt(h.slice(4, 6), 16),
  ];
}

function channel(n: number): string {
  return Math.max(0, Math.min(255, Math.round(n)))
    .toString(16)
    .padStart(2, "0");
}

export function rgbToHex(r: number, g: number, b: number): string {
  return `#${channel(r)}${channel(g)}${channel(b)}`;
}

/** Linear mix of two hex colours. amount = 0 → hex, amount = 1 → other. */
export function mix(hex: string, other: string, amount: number): string {
  const [r1, g1, b1] = hexToRgb(hex);
  const [r2, g2, b2] = hexToRgb(other);
  return rgbToHex(
    r1 + (r2 - r1) * amount,
    g1 + (g2 - g1) * amount,
    b1 + (b2 - b1) * amount,
  );
}

/** WCAG relative luminance, 0 (black) – 1 (white). */
export function luminance(hex: string): number {
  const [r, g, b] = hexToRgb(hex).map((v) => {
    const c = v / 255;
    return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

/** Text colour that stays readable on top of the given background. */
export function readableOn(hex: string): string {
  return luminance(hex) > 0.4 ? "#111827" : "#ffffff";
}

/** CSS custom properties consumed by .btn-brand, .input, and theme components. */
export function brandVars(hex: string): CSSProperties {
  const safe = isValidHex(hex) ? hex : "#6d5efc";
  const [r, g, b] = hexToRgb(safe);
  return {
    "--brand": safe,
    "--brand-strong": mix(safe, "#000000", 0.14),
    "--brand-soft": mix(safe, "#ffffff", 0.9),
    "--brand-ring": `rgba(${r}, ${g}, ${b}, 0.28)`,
    "--brand-contrast": readableOn(safe),
  } as CSSProperties;
}

/** Darkens light brand colours so the QR code always stays scannable. */
export function qrDarkColor(hex: string): string {
  const safe = isValidHex(hex) ? hex : "#111827";
  return luminance(safe) > 0.35 ? mix(safe, "#000000", 0.55) : safe;
}
