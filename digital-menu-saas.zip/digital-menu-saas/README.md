# سوقي — Multi-niche Store & Menu SaaS

Next.js (App Router) · TypeScript · Tailwind CSS · Framer Motion · RTL Arabic (Tajawal)

## Run

```bash
npm install
npm run dev        # http://localhost:3000
npm run typecheck
npm run build
```

## Routes

| Route | What it is |
| --- | --- |
| `/` | Landing page: hero with live phone mockup, features, niches, steps, pricing |
| `/dashboard` | Onboarding, store settings + theme switcher, products, QR generator |
| `/[brand]` | Public storefront. Theme is picked from the merchant's niche |
| `/cafe-demo`, `/glow-demo`, `/urban-demo` | Built-in demo stores (food, cosmetics, retail) |

## Structure

- `lib/` types, theme config, demo data, storage hook, cart hook, WhatsApp message builder
- `components/storefront/` theme engine (`Storefront.tsx`), three themes, cart drawer, floating cart
- `components/dashboard/` onboarding, settings, product manager, QR panel
- `components/landing/` landing sections

## Persistence

The demo stores everything in `localStorage` (`lib/store.ts`, `lib/cart.ts`), so the
storefront only resolves on the same browser the merchant used. For production, replace
`readStore` / `writeStore` with API calls to a database and make `app/[brand]/page.tsx`
fetch the store on the server.
